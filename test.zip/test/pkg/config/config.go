package config

import (
	"fmt"
	"strings"

	"github.com/spf13/viper"
)

// AppConfig 应用总配置
type AppConfig struct {
	ServiceName string           `mapstructure:"service_name"`
	Env         string           `mapstructure:"env"`
	Log         LogConfig        `mapstructure:"log"`
	GRPC        GRPCConfig       `mapstructure:"grpc"`
	HTTP        HTTPConfig       `mapstructure:"http"`
	Database    DatabaseConfig   `mapstructure:"database"`
	ClickHouse  ClickHouseConfig `mapstructure:"clickhouse"`
	Redis       RedisConfig      `mapstructure:"redis"`
	Kafka       KafkaConfig      `mapstructure:"kafka"`
	JWT         JWTConfig        `mapstructure:"jwt"`
}

type LogConfig struct {
	Level  string `mapstructure:"level"`
	Format string `mapstructure:"format"` // json or text
}

type GRPCConfig struct {
	Port int `mapstructure:"port"`
}

type HTTPConfig struct {
	Port int `mapstructure:"port"`
}

type DatabaseConfig struct {
	Host     string `mapstructure:"host"`
	Port     int    `mapstructure:"port"`
	User     string `mapstructure:"user"`
	Password string `mapstructure:"password"`
	DBName   string `mapstructure:"dbname"`
	SSLMode  string `mapstructure:"sslmode"`
	MaxConns int    `mapstructure:"max_conns"`
}

func (c DatabaseConfig) DSN() string {
	return fmt.Sprintf("postgres://%s:%s@%s:%d/%s?sslmode=%s",
		c.User, c.Password, c.Host, c.Port, c.DBName, c.SSLMode)
}

type ClickHouseConfig struct {
	Host     string `mapstructure:"host"`
	Port     int    `mapstructure:"port"`
	User     string `mapstructure:"user"`
	Password string `mapstructure:"password"`
	Database string `mapstructure:"database"`
}

type RedisConfig struct {
	Addr     string `mapstructure:"addr"`
	Password string `mapstructure:"password"`
	DB       int    `mapstructure:"db"`
}

type KafkaConfig struct {
	Brokers []string `mapstructure:"brokers"`
	GroupID string   `mapstructure:"group_id"`
}

type JWTConfig struct {
	Secret     string `mapstructure:"secret"`
	ExpireHour int    `mapstructure:"expire_hour"`
}

// Load 加载配置，支持环境变量覆盖
func Load(serviceName string) (*AppConfig, error) {
	v := viper.New()
	v.SetConfigName("config")
	v.SetConfigType("yaml")
	v.AddConfigPath("./configs")
	v.AddConfigPath(".")

	v.SetEnvPrefix("QUANT")
	v.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))
	v.AutomaticEnv()

	if err := v.ReadInConfig(); err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}

	cfg := &AppConfig{}
	if err := v.Unmarshal(cfg); err != nil {
		return nil, fmt.Errorf("unmarshal config: %w", err)
	}

	if serviceName != "" {
		cfg.ServiceName = serviceName
	}

	return cfg, nil
}
