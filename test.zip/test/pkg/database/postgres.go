package database

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/quant-platform/server/pkg/config"
)

// PostgresDB PostgreSQL数据库连接
type PostgresDB struct {
	Pool *pgxpool.Pool
}

// NewPostgres 创建PostgreSQL连接池
func NewPostgres(ctx context.Context, cfg config.DatabaseConfig) (*PostgresDB, error) {
	poolCfg, err := pgxpool.ParseConfig(cfg.DSN())
	if err != nil {
		return nil, fmt.Errorf("parse postgres config: %w", err)
	}

	if cfg.MaxConns > 0 {
		poolCfg.MaxConns = int32(cfg.MaxConns)
	}

	pool, err := pgxpool.NewWithConfig(ctx, poolCfg)
	if err != nil {
		return nil, fmt.Errorf("connect postgres: %w", err)
	}

	if err := pool.Ping(ctx); err != nil {
		pool.Close()
		return nil, fmt.Errorf("ping postgres: %w", err)
	}

	return &PostgresDB{Pool: pool}, nil
}

// Close 关闭连接池
func (db *PostgresDB) Close() {
	if db.Pool != nil {
		db.Pool.Close()
	}
}
