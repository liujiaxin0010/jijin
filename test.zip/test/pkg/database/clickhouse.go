package database

import (
	"database/sql"
	"fmt"

	"github.com/quant-platform/server/pkg/config"
)

// ClickHouseDB ClickHouse时序数据库连接
type ClickHouseDB struct {
	DB *sql.DB
}

// NewClickHouse 创建ClickHouse连接
func NewClickHouse(cfg config.ClickHouseConfig) (*ClickHouseDB, error) {
	dsn := fmt.Sprintf("clickhouse://%s:%s@%s:%d/%s",
		cfg.User, cfg.Password, cfg.Host, cfg.Port, cfg.Database)

	db, err := sql.Open("clickhouse", dsn)
	if err != nil {
		return nil, fmt.Errorf("open clickhouse: %w", err)
	}

	if err := db.Ping(); err != nil {
		db.Close()
		return nil, fmt.Errorf("ping clickhouse: %w", err)
	}

	return &ClickHouseDB{DB: db}, nil
}

// Close 关闭连接
func (ch *ClickHouseDB) Close() {
	if ch.DB != nil {
		ch.DB.Close()
	}
}
