package models

// Exchange 交易所
type Exchange string

const (
	ExchangeSSE  Exchange = "SSE"  // 上海证券交易所
	ExchangeSZSE Exchange = "SZSE" // 深圳证券交易所
	ExchangeCFFE Exchange = "CFFE" // 中国金融期货交易所
	ExchangeSHFE Exchange = "SHFE" // 上海期货交易所
	ExchangeDCE  Exchange = "DCE"  // 大连商品交易所
	ExchangeCZCE Exchange = "CZCE" // 郑州商品交易所
	ExchangeHKEX Exchange = "HKEX" // 香港交易所
)

// AssetType 资产类型
type AssetType string

const (
	AssetStock  AssetType = "STOCK"
	AssetFund   AssetType = "FUND"
	AssetBond   AssetType = "BOND"
	AssetFuture AssetType = "FUTURE"
	AssetOption AssetType = "OPTION"
	AssetETF    AssetType = "ETF"
)
