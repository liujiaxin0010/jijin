package models

// OrderSide 订单方向
type OrderSide string

const (
	OrderBuy  OrderSide = "BUY"
	OrderSell OrderSide = "SELL"
)

// OrderType 订单类型
type OrderType string

const (
	OrderMarket    OrderType = "MARKET"
	OrderLimit     OrderType = "LIMIT"
	OrderStop      OrderType = "STOP"
	OrderStopLimit OrderType = "STOP_LIMIT"
)

// OrderStatus 订单状态
type OrderStatus string

const (
	OrderPending       OrderStatus = "PENDING"
	OrderSubmitted     OrderStatus = "SUBMITTED"
	OrderPartialFilled OrderStatus = "PARTIAL_FILLED"
	OrderFilled        OrderStatus = "FILLED"
	OrderCancelled     OrderStatus = "CANCELLED"
	OrderRejected      OrderStatus = "REJECTED"
	OrderFailed        OrderStatus = "FAILED"
)
