package models

// Timeframe K线周期
type Timeframe string

const (
	Timeframe1m  Timeframe = "1m"
	Timeframe5m  Timeframe = "5m"
	Timeframe15m Timeframe = "15m"
	Timeframe30m Timeframe = "30m"
	Timeframe1h  Timeframe = "1h"
	Timeframe4h  Timeframe = "4h"
	Timeframe1d  Timeframe = "1d"
	Timeframe1w  Timeframe = "1w"
	Timeframe1M  Timeframe = "1M"
)

// RiskLevel 预警级别
type RiskLevel string

const (
	RiskYellow RiskLevel = "YELLOW" // 黄色预警: 接近阈值80%
	RiskOrange RiskLevel = "ORANGE" // 橙色预警: 达到阈值100%
	RiskRed    RiskLevel = "RED"    // 红色预警: 超过阈值120%
	RiskBlack  RiskLevel = "BLACK"  // 黑色预警: 系统异常
)

// StrategyStatus 策略状态
type StrategyStatus string

const (
	StrategyDraft   StrategyStatus = "DRAFT"
	StrategyActive  StrategyStatus = "ACTIVE"
	StrategyStopped StrategyStatus = "STOPPED"
	StrategyError   StrategyStatus = "ERROR"
)
