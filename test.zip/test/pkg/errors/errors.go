package errors

import "fmt"

// ErrorCode 应用错误码
type ErrorCode int

const (
	ErrInternal          ErrorCode = 10000
	ErrInvalidArgument   ErrorCode = 10001
	ErrNotFound          ErrorCode = 10002
	ErrAlreadyExists     ErrorCode = 10003
	ErrPermissionDenied  ErrorCode = 10004
	ErrUnauthenticated   ErrorCode = 10005
	ErrInsufficientFunds ErrorCode = 20001
	ErrRiskLimitExceeded ErrorCode = 20002
	ErrMarketClosed      ErrorCode = 20003
	ErrOrderRejected     ErrorCode = 20004
	ErrStrategyFailed    ErrorCode = 20005
	ErrDataUnavailable   ErrorCode = 20006
)

// AppError 统一应用错误
type AppError struct {
	Code    ErrorCode `json:"code"`
	Message string    `json:"message"`
	Cause   error     `json:"-"`
}

func (e *AppError) Error() string {
	if e.Cause != nil {
		return fmt.Sprintf("[%d] %s: %v", e.Code, e.Message, e.Cause)
	}
	return fmt.Sprintf("[%d] %s", e.Code, e.Message)
}

func (e *AppError) Unwrap() error {
	return e.Cause
}

func New(code ErrorCode, msg string) *AppError {
	return &AppError{Code: code, Message: msg}
}

func Wrap(code ErrorCode, msg string, cause error) *AppError {
	return &AppError{Code: code, Message: msg, Cause: cause}
}

func NotFound(entity string, id interface{}) *AppError {
	return New(ErrNotFound, fmt.Sprintf("%s not found: %v", entity, id))
}

func InvalidArgument(msg string) *AppError {
	return New(ErrInvalidArgument, msg)
}

func Internal(msg string, cause error) *AppError {
	return Wrap(ErrInternal, msg, cause)
}
