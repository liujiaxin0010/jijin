package messaging

// Kafka Topic 常量定义
const (
	TopicMarketTick     = "market.data.tick"
	TopicMarketKline    = "market.data.kline"
	TopicOrderCreated   = "order.created"
	TopicOrderFilled    = "order.filled"
	TopicOrderCancelled = "order.cancelled"
	TopicRiskAlert      = "risk.alert"
	TopicStrategySignal = "strategy.signal"
	TopicRebalance      = "portfolio.rebalance"
	TopicNotification   = "notification.send"
	TopicFactorUpdated  = "factor.updated"
	TopicBacktestDone   = "backtest.done"
)
