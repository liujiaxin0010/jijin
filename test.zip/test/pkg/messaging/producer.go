package messaging

import (
	"context"
	"fmt"

	"github.com/segmentio/kafka-go"
	"github.com/quant-platform/server/pkg/config"
)

// Producer Kafka消息生产者
type Producer struct {
	writer *kafka.Writer
}

// NewProducer 创建Kafka生产者
func NewProducer(cfg config.KafkaConfig) *Producer {
	w := &kafka.Writer{
		Addr:     kafka.TCP(cfg.Brokers...),
		Balancer: &kafka.LeastBytes{},
	}
	return &Producer{writer: w}
}

// Publish 发布消息到指定Topic
func (p *Producer) Publish(ctx context.Context, topic, key string, value []byte) error {
	msg := kafka.Message{
		Topic: topic,
		Key:   []byte(key),
		Value: value,
	}
	if err := p.writer.WriteMessages(ctx, msg); err != nil {
		return fmt.Errorf("publish to %s: %w", topic, err)
	}
	return nil
}

// Close 关闭生产者
func (p *Producer) Close() error {
	return p.writer.Close()
}
