package messaging

import (
	"context"
	"fmt"
	"log/slog"

	"github.com/segmentio/kafka-go"
	"github.com/quant-platform/server/pkg/config"
)

// Handler 消息处理函数
type Handler func(ctx context.Context, key, value []byte) error

// Consumer Kafka消息消费者
type Consumer struct {
	reader *kafka.Reader
	log    *slog.Logger
}

// NewConsumer 创建Kafka消费者
func NewConsumer(cfg config.KafkaConfig, topic string, log *slog.Logger) *Consumer {
	r := kafka.NewReader(kafka.ReaderConfig{
		Brokers: cfg.Brokers,
		GroupID: cfg.GroupID,
		Topic:   topic,
	})
	return &Consumer{reader: r, log: log}
}

// Consume 开始消费消息
func (c *Consumer) Consume(ctx context.Context, handler Handler) error {
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
			msg, err := c.reader.ReadMessage(ctx)
			if err != nil {
				if ctx.Err() != nil {
					return ctx.Err()
				}
				c.log.Error("read message failed", "error", err)
				continue
			}
			if err := handler(ctx, msg.Key, msg.Value); err != nil {
				c.log.Error("handle message failed",
					"topic", msg.Topic,
					"error", err,
				)
			}
		}
	}
}

// Close 关闭消费者
func (c *Consumer) Close() error {
	return c.reader.Close()
}

// ConsumeWithRetry 带重试的消费
func (c *Consumer) ConsumeWithRetry(ctx context.Context, handler Handler, maxRetries int) error {
	return c.Consume(ctx, func(ctx context.Context, key, value []byte) error {
		var lastErr error
		for i := 0; i <= maxRetries; i++ {
			if err := handler(ctx, key, value); err != nil {
				lastErr = err
				c.log.Warn("handler retry", "attempt", i+1, "error", err)
				continue
			}
			return nil
		}
		return fmt.Errorf("max retries exceeded: %w", lastErr)
	})
}
