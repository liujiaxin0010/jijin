package domain

import "context"

// OrderRepository 订单仓储接口
type OrderRepository interface {
	Create(ctx context.Context, order *Order) error
	GetByID(ctx context.Context, id string) (*Order, error)
	ListByAccount(ctx context.Context, accountID string, status string) ([]Order, error)
	UpdateStatus(ctx context.Context, id string, status string) error
	Update(ctx context.Context, order *Order) error
}

// TradeRepository 成交仓储接口
type TradeRepository interface {
	Create(ctx context.Context, trade *Trade) error
	ListByOrder(ctx context.Context, orderID string) ([]Trade, error)
	ListByAccount(ctx context.Context, accountID string) ([]Trade, error)
}
