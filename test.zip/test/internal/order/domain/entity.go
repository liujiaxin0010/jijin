package domain

import (
	"time"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/pkg/models"
)

// Order 订单
type Order struct {
	ID             string             `json:"id"`
	AccountID      string             `json:"account_id"`
	StrategyID     string             `json:"strategy_id"`
	Symbol         string             `json:"symbol"`
	Exchange       models.Exchange    `json:"exchange"`
	Side           models.OrderSide   `json:"side"`
	Type           models.OrderType   `json:"type"`
	Status         models.OrderStatus `json:"status"`
	Quantity       int64              `json:"quantity"`
	Price          decimal.Decimal    `json:"price"`
	FilledQty      int64              `json:"filled_qty"`
	AvgFillPrice   decimal.Decimal    `json:"avg_fill_price"`
	Commission     decimal.Decimal    `json:"commission"`
	SlippageCost   decimal.Decimal    `json:"slippage_cost"`
	Reason         string             `json:"reason"`
	CreatedAt      time.Time          `json:"created_at"`
	UpdatedAt      time.Time          `json:"updated_at"`
}

// Trade 成交记录
type Trade struct {
	ID        string          `json:"id"`
	OrderID   string          `json:"order_id"`
	Symbol    string          `json:"symbol"`
	Side      models.OrderSide `json:"side"`
	Price     decimal.Decimal `json:"price"`
	Quantity  int64           `json:"quantity"`
	Commission decimal.Decimal `json:"commission"`
	TradeTime time.Time       `json:"trade_time"`
}
