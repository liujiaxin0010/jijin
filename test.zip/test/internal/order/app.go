package order

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/quant-platform/server/internal/order/domain"
	"github.com/quant-platform/server/internal/order/service"
	"github.com/quant-platform/server/pkg/config"
	"github.com/quant-platform/server/pkg/middleware"
)

// App 订单服务应用
type App struct {
	cfg     *config.AppConfig
	log     *slog.Logger
	svc     *service.OrderService
	httpSrv *http.Server
}

// NewApp 创建应用实例
func NewApp(ctx context.Context, cfg *config.AppConfig, log *slog.Logger) (*App, error) {
	svc := service.NewOrderService(nil, nil, log)
	return &App{cfg: cfg, log: log, svc: svc}, nil
}

// Run 启动服务
func (a *App) Run(ctx context.Context) error {
	router := gin.New()
	router.Use(middleware.Logger(a.log), middleware.Recovery(a.log), middleware.CORS())

	api := router.Group("/api/v1")
	a.registerRoutes(api)

	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok", "service": "order"})
	})

	a.httpSrv = &http.Server{
		Addr:    fmt.Sprintf(":%d", a.cfg.HTTP.Port),
		Handler: router,
	}

	errCh := make(chan error, 1)
	go func() {
		if err := a.httpSrv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			errCh <- err
		}
	}()

	select {
	case <-ctx.Done():
		a.log.Info("shutting down order service")
		return a.httpSrv.Shutdown(context.Background())
	case err := <-errCh:
		return fmt.Errorf("http server error: %w", err)
	}
}

func (a *App) registerRoutes(r *gin.RouterGroup) {
	g := r.Group("/orders")

	g.POST("", func(c *gin.Context) {
		var order domain.Order
		if err := c.ShouldBindJSON(&order); err != nil {
			c.JSON(400, gin.H{"error": err.Error()})
			return
		}
		if err := a.svc.CreateOrder(c.Request.Context(), &order); err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		c.JSON(201, gin.H{"data": order})
	})

	g.DELETE("/:id", func(c *gin.Context) {
		if err := a.svc.CancelOrder(c.Request.Context(), c.Param("id")); err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		c.JSON(200, gin.H{"message": "cancelled"})
	})

	g.GET("/:id", func(c *gin.Context) {
		order, err := a.svc.GetOrder(c.Request.Context(), c.Param("id"))
		if err != nil {
			c.JSON(404, gin.H{"error": err.Error()})
			return
		}
		c.JSON(200, gin.H{"data": order})
	})

	g.GET("", func(c *gin.Context) {
		orders, err := a.svc.ListOrders(c.Request.Context(), c.Query("account_id"), c.Query("status"))
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		c.JSON(200, gin.H{"data": orders})
	})
}
