package service

import (
	"context"
	"fmt"
	"log/slog"
	"time"

	"github.com/quant-platform/server/internal/order/domain"
	"github.com/quant-platform/server/pkg/models"
)

// OrderService 订单业务服务
type OrderService struct {
	orderRepo domain.OrderRepository
	tradeRepo domain.TradeRepository
	log       *slog.Logger
}

// NewOrderService 创建订单服务
func NewOrderService(
	orderRepo domain.OrderRepository,
	tradeRepo domain.TradeRepository,
	log *slog.Logger,
) *OrderService {
	return &OrderService{
		orderRepo: orderRepo,
		tradeRepo: tradeRepo,
		log:       log,
	}
}

// CreateOrder 创建订单
func (s *OrderService) CreateOrder(ctx context.Context, order *domain.Order) error {
	if order.Symbol == "" {
		return fmt.Errorf("symbol is required")
	}
	if order.Quantity <= 0 {
		return fmt.Errorf("quantity must be positive")
	}
	order.Status = models.OrderPending
	order.CreatedAt = time.Now()
	order.UpdatedAt = time.Now()
	return s.orderRepo.Create(ctx, order)
}

// CancelOrder 撤销订单
func (s *OrderService) CancelOrder(ctx context.Context, id string) error {
	order, err := s.orderRepo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if order.Status == models.OrderFilled || order.Status == models.OrderCancelled {
		return fmt.Errorf("order cannot be cancelled in status: %s", order.Status)
	}
	return s.orderRepo.UpdateStatus(ctx, id, string(models.OrderCancelled))
}

// GetOrder 获取订单
func (s *OrderService) GetOrder(ctx context.Context, id string) (*domain.Order, error) {
	return s.orderRepo.GetByID(ctx, id)
}

// ListOrders 列出订单
func (s *OrderService) ListOrders(ctx context.Context, accountID, status string) ([]domain.Order, error) {
	return s.orderRepo.ListByAccount(ctx, accountID, status)
}

// ListTrades 列出成交
func (s *OrderService) ListTrades(ctx context.Context, accountID string) ([]domain.Trade, error) {
	return s.tradeRepo.ListByAccount(ctx, accountID)
}
