package service

import (
	"context"
	"fmt"
	"log/slog"
	"time"

	"github.com/google/uuid"
	"github.com/quant-platform/server/internal/notification/domain"
)

// NotificationService 通知服务
type NotificationService struct {
	notifRepo   domain.NotificationRepository
	channelRepo domain.NotificationChannelRepository
	log         *slog.Logger
}

// NewNotificationService 创建通知服务
func NewNotificationService(
	notifRepo domain.NotificationRepository,
	channelRepo domain.NotificationChannelRepository,
	log *slog.Logger,
) *NotificationService {
	return &NotificationService{
		notifRepo:   notifRepo,
		channelRepo: channelRepo,
		log:         log,
	}
}

// Send 发送通知
func (s *NotificationService) Send(ctx context.Context, n *domain.Notification) error {
	n.ID = uuid.New().String()
	n.Status = "pending"
	n.CreatedAt = time.Now()

	if err := s.notifRepo.Create(ctx, n); err != nil {
		return fmt.Errorf("create notification: %w", err)
	}

	// 实际发送
	if err := s.dispatch(ctx, n); err != nil {
		_ = s.notifRepo.UpdateStatus(ctx, n.ID, "failed")
		return fmt.Errorf("dispatch notification: %w", err)
	}

	n.SentAt = timePtr(time.Now())
	_ = s.notifRepo.UpdateStatus(ctx, n.ID, "sent")
	s.log.Info("notification sent", "id", n.ID, "channel", n.Channel, "type", n.Type)
	return nil
}

// dispatch 分发通知到具体渠道
func (s *NotificationService) dispatch(ctx context.Context, n *domain.Notification) error {
	switch n.Channel {
	case "email":
		return s.sendEmail(ctx, n)
	case "sms":
		return s.sendSMS(ctx, n)
	case "websocket":
		return s.sendWebSocket(ctx, n)
	default:
		return fmt.Errorf("unsupported channel: %s", n.Channel)
	}
}

// sendEmail 发送邮件通知
func (s *NotificationService) sendEmail(_ context.Context, n *domain.Notification) error {
	// TODO: 集成SMTP邮件发送
	s.log.Info("sending email", "to", n.AccountID, "title", n.Title)
	return nil
}

// sendSMS 发送短信通知
func (s *NotificationService) sendSMS(_ context.Context, n *domain.Notification) error {
	// TODO: 集成短信网关
	s.log.Info("sending sms", "to", n.AccountID, "title", n.Title)
	return nil
}

// sendWebSocket 发送WebSocket通知
func (s *NotificationService) sendWebSocket(_ context.Context, n *domain.Notification) error {
	// TODO: 集成WebSocket推送
	s.log.Info("sending websocket", "to", n.AccountID, "title", n.Title)
	return nil
}

// GetNotification 获取通知详情
func (s *NotificationService) GetNotification(ctx context.Context, id string) (*domain.Notification, error) {
	return s.notifRepo.GetByID(ctx, id)
}

// ListNotifications 获取通知列表
func (s *NotificationService) ListNotifications(ctx context.Context, accountID string) ([]domain.Notification, error) {
	return s.notifRepo.List(ctx, accountID)
}

// MarkRead 标记已读
func (s *NotificationService) MarkRead(ctx context.Context, id string) error {
	return s.notifRepo.MarkRead(ctx, id)
}

// CreateChannel 创建通知渠道
func (s *NotificationService) CreateChannel(ctx context.Context, ch *domain.NotificationChannel) error {
	ch.ID = uuid.New().String()
	ch.CreatedAt = time.Now()
	ch.UpdatedAt = time.Now()
	return s.channelRepo.Create(ctx, ch)
}

// ListChannels 获取通知渠道列表
func (s *NotificationService) ListChannels(ctx context.Context, accountID string) ([]domain.NotificationChannel, error) {
	return s.channelRepo.List(ctx, accountID)
}

// UpdateChannel 更新通知渠道
func (s *NotificationService) UpdateChannel(ctx context.Context, ch *domain.NotificationChannel) error {
	ch.UpdatedAt = time.Now()
	return s.channelRepo.Update(ctx, ch)
}

func timePtr(t time.Time) *time.Time {
	return &t
}
