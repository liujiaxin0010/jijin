package notification

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"

	"github.com/gin-gonic/gin"
	handler "github.com/quant-platform/server/internal/notification/handler/http"
	"github.com/quant-platform/server/internal/notification/service"
	"github.com/quant-platform/server/pkg/config"
	"github.com/quant-platform/server/pkg/middleware"
)

// App 通知服务应用
type App struct {
	cfg     *config.AppConfig
	log     *slog.Logger
	svc     *service.NotificationService
	httpSrv *http.Server
}

// NewApp 创建应用实例
func NewApp(ctx context.Context, cfg *config.AppConfig, log *slog.Logger) (*App, error) {
	svc := service.NewNotificationService(nil, nil, log)
	return &App{cfg: cfg, log: log, svc: svc}, nil
}

// Run 启动服务
func (a *App) Run(ctx context.Context) error {
	router := gin.New()
	router.Use(middleware.Logger(a.log), middleware.Recovery(a.log), middleware.CORS())

	api := router.Group("/api/v1")
	h := handler.NewHandler(a.svc)
	h.RegisterRoutes(api)

	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok", "service": "notification"})
	})

	a.httpSrv = &http.Server{
		Addr:    fmt.Sprintf(":%d", a.cfg.HTTP.Port),
		Handler: router,
	}

	errCh := make(chan error, 1)
	go func() {
		if err := a.httpSrv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			errCh <- err
		}
	}()

	select {
	case <-ctx.Done():
		a.log.Info("shutting down notification service")
		return a.httpSrv.Shutdown(context.Background())
	case err := <-errCh:
		return fmt.Errorf("http server error: %w", err)
	}
}
