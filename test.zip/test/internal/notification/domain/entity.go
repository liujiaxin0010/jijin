package domain

import "time"

// Notification 通知
type Notification struct {
	ID        string    `json:"id"`
	AccountID string    `json:"account_id"`
	Channel   string    `json:"channel"` // email, sms, websocket
	Type      string    `json:"type"`    // alert, trade, system
	Title     string    `json:"title"`
	Content   string    `json:"content"`
	Status    string     `json:"status"` // pending, sent, failed
	ReadAt    *time.Time `json:"read_at"`
	SentAt    *time.Time `json:"sent_at"`
	CreatedAt time.Time  `json:"created_at"`
}

// NotificationChannel 通知渠道配置
type NotificationChannel struct {
	ID        string            `json:"id"`
	AccountID string            `json:"account_id"`
	Channel   string            `json:"channel"` // email, sms, websocket
	Enabled   bool              `json:"enabled"`
	Config    map[string]string `json:"config"` // 渠道配置(邮箱地址、手机号等)
	CreatedAt time.Time         `json:"created_at"`
	UpdatedAt time.Time         `json:"updated_at"`
}
