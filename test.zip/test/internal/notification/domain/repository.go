package domain

import "context"

// NotificationRepository 通知仓储
type NotificationRepository interface {
	Create(ctx context.Context, n *Notification) error
	GetByID(ctx context.Context, id string) (*Notification, error)
	List(ctx context.Context, accountID string) ([]Notification, error)
	MarkRead(ctx context.Context, id string) error
	UpdateStatus(ctx context.Context, id string, status string) error
}

// NotificationChannelRepository 通知渠道仓储
type NotificationChannelRepository interface {
	Create(ctx context.Context, ch *NotificationChannel) error
	List(ctx context.Context, accountID string) ([]NotificationChannel, error)
	Update(ctx context.Context, ch *NotificationChannel) error
}
