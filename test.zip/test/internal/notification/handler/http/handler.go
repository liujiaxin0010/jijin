package http

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/quant-platform/server/internal/notification/domain"
	"github.com/quant-platform/server/internal/notification/service"
)

// Handler 通知HTTP处理器
type Handler struct {
	svc *service.NotificationService
}

// NewHandler 创建处理器
func NewHandler(svc *service.NotificationService) *Handler {
	return &Handler{svc: svc}
}

// RegisterRoutes 注册路由
func (h *Handler) RegisterRoutes(r *gin.RouterGroup) {
	notifications := r.Group("/notifications")
	{
		notifications.POST("", h.send)
		notifications.GET("", h.list)
		notifications.GET("/:id", h.get)
		notifications.PUT("/:id/read", h.markRead)
	}

	channels := r.Group("/notification-channels")
	{
		channels.POST("", h.createChannel)
		channels.GET("", h.listChannels)
		channels.PUT("/:id", h.updateChannel)
	}
}

// send 发送通知
func (h *Handler) send(c *gin.Context) {
	var n domain.Notification
	if err := c.ShouldBindJSON(&n); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := h.svc.Send(c.Request.Context(), &n); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, gin.H{"data": n})
}

// list 获取通知列表
func (h *Handler) list(c *gin.Context) {
	accountID := c.Query("account_id")
	notifications, err := h.svc.ListNotifications(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": notifications})
}

// get 获取通知详情
func (h *Handler) get(c *gin.Context) {
	n, err := h.svc.GetNotification(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": n})
}

// markRead 标记已读
func (h *Handler) markRead(c *gin.Context) {
	if err := h.svc.MarkRead(c.Request.Context(), c.Param("id")); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "marked as read"})
}

// createChannel 创建通知渠道
func (h *Handler) createChannel(c *gin.Context) {
	var ch domain.NotificationChannel
	if err := c.ShouldBindJSON(&ch); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := h.svc.CreateChannel(c.Request.Context(), &ch); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, gin.H{"data": ch})
}

// listChannels 获取通知渠道列表
func (h *Handler) listChannels(c *gin.Context) {
	accountID := c.Query("account_id")
	chs, err := h.svc.ListChannels(c.Request.Context(), accountID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": chs})
}

// updateChannel 更新通知渠道
func (h *Handler) updateChannel(c *gin.Context) {
	var ch domain.NotificationChannel
	if err := c.ShouldBindJSON(&ch); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	ch.ID = c.Param("id")
	if err := h.svc.UpdateChannel(c.Request.Context(), &ch); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": ch})
}
