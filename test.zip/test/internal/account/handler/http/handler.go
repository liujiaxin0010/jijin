package http

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/quant-platform/server/internal/account/domain"
	"github.com/quant-platform/server/internal/account/service"
)

// Handler 账户HTTP处理器
type Handler struct {
	svc *service.AccountService
}

// NewHandler 创建HTTP处理器
func NewHandler(svc *service.AccountService) *Handler {
	return &Handler{svc: svc}
}

// RegisterRoutes 注册路由
func (h *Handler) RegisterRoutes(r *gin.RouterGroup) {
	users := r.Group("/users")
	users.POST("", h.CreateUser)
	users.GET("/:id", h.GetUser)

	accounts := r.Group("/accounts")
	accounts.POST("", h.CreateAccount)
	accounts.GET("/:id", h.GetAccount)
	accounts.GET("/user/:user_id", h.ListAccounts)
	accounts.GET("/:id/positions", h.GetPositions)
}

// CreateUser 创建用户
func (h *Handler) CreateUser(c *gin.Context) {
	var user domain.User
	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := h.svc.CreateUser(c.Request.Context(), &user); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, gin.H{"data": user})
}

// GetUser 获取用户
func (h *Handler) GetUser(c *gin.Context) {
	user, err := h.svc.GetUser(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": user})
}

// CreateAccount 创建账户
func (h *Handler) CreateAccount(c *gin.Context) {
	var acct domain.Account
	if err := c.ShouldBindJSON(&acct); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := h.svc.CreateAccount(c.Request.Context(), &acct); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, gin.H{"data": acct})
}

// GetAccount 获取账户
func (h *Handler) GetAccount(c *gin.Context) {
	acct, err := h.svc.GetAccount(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": acct})
}

// ListAccounts 列出用户账户
func (h *Handler) ListAccounts(c *gin.Context) {
	accounts, err := h.svc.ListAccounts(c.Request.Context(), c.Param("user_id"))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": accounts})
}

// GetPositions 获取持仓
func (h *Handler) GetPositions(c *gin.Context) {
	positions, err := h.svc.GetPositions(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": positions})
}
