package service

import (
	"context"
	"fmt"
	"log/slog"

	"github.com/quant-platform/server/internal/account/domain"
)

// AccountService 账户业务服务
type AccountService struct {
	userRepo    domain.UserRepository
	accountRepo domain.AccountRepository
	posRepo     domain.PositionRepository
	log         *slog.Logger
}

// NewAccountService 创建账户服务
func NewAccountService(
	userRepo domain.UserRepository,
	accountRepo domain.AccountRepository,
	posRepo domain.PositionRepository,
	log *slog.Logger,
) *AccountService {
	return &AccountService{
		userRepo:    userRepo,
		accountRepo: accountRepo,
		posRepo:     posRepo,
		log:         log,
	}
}

// CreateUser 创建用户
func (s *AccountService) CreateUser(ctx context.Context, user *domain.User) error {
	if user.Username == "" {
		return fmt.Errorf("username is required")
	}
	return s.userRepo.Create(ctx, user)
}

// GetUser 获取用户
func (s *AccountService) GetUser(ctx context.Context, id string) (*domain.User, error) {
	return s.userRepo.GetByID(ctx, id)
}

// CreateAccount 创建交易账户
func (s *AccountService) CreateAccount(ctx context.Context, acct *domain.Account) error {
	return s.accountRepo.Create(ctx, acct)
}

// GetAccount 获取账户
func (s *AccountService) GetAccount(ctx context.Context, id string) (*domain.Account, error) {
	return s.accountRepo.GetByID(ctx, id)
}

// ListAccounts 列出用户账户
func (s *AccountService) ListAccounts(ctx context.Context, userID string) ([]domain.Account, error) {
	return s.accountRepo.ListByUser(ctx, userID)
}

// GetPositions 获取持仓列表
func (s *AccountService) GetPositions(ctx context.Context, accountID string) ([]domain.Position, error) {
	return s.posRepo.ListByAccount(ctx, accountID)
}
