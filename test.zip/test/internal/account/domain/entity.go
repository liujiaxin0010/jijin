package domain

import (
	"time"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/pkg/models"
)

// User 用户
type User struct {
	ID        string    `json:"id"`
	Username  string    `json:"username"`
	Email     string    `json:"email"`
	Phone     string    `json:"phone"`
	Role      string    `json:"role"` // admin, manager, trader, viewer
	Status    string    `json:"status"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

// Account 交易账户
type Account struct {
	ID            string          `json:"id"`
	UserID        string          `json:"user_id"`
	Name          string          `json:"name"`
	Type          string          `json:"type"` // stock, future, option
	Balance       decimal.Decimal `json:"balance"`
	Available     decimal.Decimal `json:"available"`
	Frozen        decimal.Decimal `json:"frozen"`
	MarketValue   decimal.Decimal `json:"market_value"`
	TotalAsset    decimal.Decimal `json:"total_asset"`
	TotalProfit   decimal.Decimal `json:"total_profit"`
	TodayProfit   decimal.Decimal `json:"today_profit"`
	Status        string          `json:"status"`
	CreatedAt     time.Time       `json:"created_at"`
	UpdatedAt     time.Time       `json:"updated_at"`
}

// Position 持仓
type Position struct {
	ID          string           `json:"id"`
	AccountID   string           `json:"account_id"`
	Symbol      string           `json:"symbol"`
	Exchange    models.Exchange  `json:"exchange"`
	Side        string           `json:"side"` // long, short
	Quantity    int64            `json:"quantity"`
	Available   int64            `json:"available"`
	Frozen      int64            `json:"frozen"`
	AvgCost     decimal.Decimal  `json:"avg_cost"`
	LastPrice   decimal.Decimal  `json:"last_price"`
	MarketValue decimal.Decimal  `json:"market_value"`
	Profit      decimal.Decimal  `json:"profit"`
	ProfitRate  decimal.Decimal  `json:"profit_rate"`
	UpdatedAt   time.Time        `json:"updated_at"`
}
