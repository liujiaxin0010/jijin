package domain

import "context"

// UserRepository 用户仓储接口
type UserRepository interface {
	Create(ctx context.Context, user *User) error
	GetByID(ctx context.Context, id string) (*User, error)
	GetByUsername(ctx context.Context, username string) (*User, error)
	Update(ctx context.Context, user *User) error
	Delete(ctx context.Context, id string) error
}

// AccountRepository 账户仓储接口
type AccountRepository interface {
	Create(ctx context.Context, account *Account) error
	GetByID(ctx context.Context, id string) (*Account, error)
	ListByUser(ctx context.Context, userID string) ([]Account, error)
	Update(ctx context.Context, account *Account) error
	UpdateBalance(ctx context.Context, id string, delta Balance) error
}

// Balance 余额变动
type Balance struct {
	Available int64
	Frozen    int64
}

// PositionRepository 持仓仓储接口
type PositionRepository interface {
	Upsert(ctx context.Context, pos *Position) error
	GetBySymbol(ctx context.Context, accountID, symbol string) (*Position, error)
	ListByAccount(ctx context.Context, accountID string) ([]Position, error)
	Delete(ctx context.Context, id string) error
}
