package risk

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/quant-platform/server/internal/risk/domain"
	"github.com/quant-platform/server/internal/risk/service"
	"github.com/quant-platform/server/pkg/config"
	"github.com/quant-platform/server/pkg/middleware"
)

// App 风控服务应用
type App struct {
	cfg     *config.AppConfig
	log     *slog.Logger
	svc     *service.RiskService
	httpSrv *http.Server
}

// NewApp 创建应用实例
func NewApp(ctx context.Context, cfg *config.AppConfig, log *slog.Logger) (*App, error) {
	svc := service.NewRiskService(nil, nil, log)
	return &App{cfg: cfg, log: log, svc: svc}, nil
}

// Run 启动服务
func (a *App) Run(ctx context.Context) error {
	router := gin.New()
	router.Use(middleware.Logger(a.log), middleware.Recovery(a.log), middleware.CORS())

	api := router.Group("/api/v1")
	a.registerRoutes(api)

	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok", "service": "risk"})
	})

	a.httpSrv = &http.Server{
		Addr:    fmt.Sprintf(":%d", a.cfg.HTTP.Port),
		Handler: router,
	}

	errCh := make(chan error, 1)
	go func() {
		if err := a.httpSrv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			errCh <- err
		}
	}()

	select {
	case <-ctx.Done():
		a.log.Info("shutting down risk service")
		return a.httpSrv.Shutdown(context.Background())
	case err := <-errCh:
		return fmt.Errorf("http server error: %w", err)
	}
}

func (a *App) registerRoutes(r *gin.RouterGroup) {
	g := r.Group("/risk")

	g.POST("/check", func(c *gin.Context) {
		var req domain.RiskCheckRequest
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(400, gin.H{"error": err.Error()})
			return
		}
		result, err := a.svc.PreTradeCheck(c.Request.Context(), &req)
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		c.JSON(200, gin.H{"data": result})
	})

	g.GET("/rules", func(c *gin.Context) {
		rules, err := a.svc.ListRules(c.Request.Context(), c.Query("account_id"))
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		c.JSON(200, gin.H{"data": rules})
	})

	g.POST("/rules", func(c *gin.Context) {
		var rule domain.RiskRule
		if err := c.ShouldBindJSON(&rule); err != nil {
			c.JSON(400, gin.H{"error": err.Error()})
			return
		}
		if err := a.svc.CreateRule(c.Request.Context(), &rule); err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		c.JSON(201, gin.H{"data": rule})
	})

	g.GET("/alerts", func(c *gin.Context) {
		alerts, err := a.svc.ListAlerts(c.Request.Context(), c.Query("account_id"), nil)
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		c.JSON(200, gin.H{"data": alerts})
	})
}
