package domain

import "context"

// RiskRuleRepository 风控规则仓储
type RiskRuleRepository interface {
	Create(ctx context.Context, rule *RiskRule) error
	GetByID(ctx context.Context, id string) (*RiskRule, error)
	List(ctx context.Context, accountID string) ([]RiskRule, error)
	Update(ctx context.Context, rule *RiskRule) error
	Delete(ctx context.Context, id string) error
}

// RiskAlertRepository 风控告警仓储
type RiskAlertRepository interface {
	Create(ctx context.Context, alert *RiskAlert) error
	List(ctx context.Context, accountID string, resolved *bool) ([]RiskAlert, error)
	Resolve(ctx context.Context, id string) error
}
