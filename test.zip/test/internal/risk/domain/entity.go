package domain

import (
	"time"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/pkg/models"
)

// RiskRule 风控规则
type RiskRule struct {
	ID          string          `json:"id"`
	Name        string          `json:"name"`
	Type        string          `json:"type"`     // position, stop_loss, drawdown, frequency, capital
	Phase       string          `json:"phase"`    // pre, during, post
	Condition   string          `json:"condition"`
	Threshold   decimal.Decimal `json:"threshold"`
	Action      string          `json:"action"`   // warn, block, liquidate, halt
	Enabled     bool            `json:"enabled"`
	AccountID   string          `json:"account_id"`
	StrategyID  string          `json:"strategy_id"`
	CreatedAt   time.Time       `json:"created_at"`
}

// RiskAlert 风控告警
type RiskAlert struct {
	ID         string          `json:"id"`
	RuleID     string          `json:"rule_id"`
	Level      models.RiskLevel `json:"level"`
	AccountID  string          `json:"account_id"`
	Symbol     string          `json:"symbol"`
	Message    string          `json:"message"`
	Value      decimal.Decimal `json:"value"`
	Threshold  decimal.Decimal `json:"threshold"`
	Action     string          `json:"action"`
	Resolved   bool            `json:"resolved"`
	CreatedAt  time.Time       `json:"created_at"`
}

// RiskCheckRequest 事前风控检查请求
type RiskCheckRequest struct {
	AccountID  string          `json:"account_id"`
	StrategyID string          `json:"strategy_id"`
	Symbol     string          `json:"symbol"`
	Side       models.OrderSide `json:"side"`
	Quantity   int64           `json:"quantity"`
	Price      decimal.Decimal `json:"price"`
}

// RiskCheckResult 风控检查结果
type RiskCheckResult struct {
	Approved   bool            `json:"approved"`
	Violations []RiskViolation `json:"violations"`
}

// RiskViolation 风控违规
type RiskViolation struct {
	RuleID   string `json:"rule_id"`
	RuleName string `json:"rule_name"`
	Severity string `json:"severity"` // warning, block
	Message  string `json:"message"`
}
