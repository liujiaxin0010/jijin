package service

import (
	"context"
	"fmt"
	"log/slog"

	"github.com/quant-platform/server/internal/risk/domain"
	"github.com/quant-platform/server/pkg/models"
)

// RiskService 风控业务服务
type RiskService struct {
	ruleRepo  domain.RiskRuleRepository
	alertRepo domain.RiskAlertRepository
	log       *slog.Logger
}

// NewRiskService 创建风控服务
func NewRiskService(
	ruleRepo domain.RiskRuleRepository,
	alertRepo domain.RiskAlertRepository,
	log *slog.Logger,
) *RiskService {
	return &RiskService{
		ruleRepo:  ruleRepo,
		alertRepo: alertRepo,
		log:       log,
	}
}

// PreTradeCheck 事前风控检查
func (s *RiskService) PreTradeCheck(ctx context.Context, req *domain.RiskCheckRequest) (*domain.RiskCheckResult, error) {
	rules, err := s.ruleRepo.List(ctx, req.AccountID)
	if err != nil {
		return nil, fmt.Errorf("list rules: %w", err)
	}

	result := &domain.RiskCheckResult{Approved: true}

	for _, rule := range rules {
		if !rule.Enabled || rule.Phase != "pre" {
			continue
		}
		violation := s.evaluateRule(&rule, req)
		if violation != nil {
			result.Violations = append(result.Violations, *violation)
			if violation.Severity == "block" {
				result.Approved = false
			}
		}
	}

	// 记录告警
	for _, v := range result.Violations {
		alert := &domain.RiskAlert{
			RuleID:    v.RuleID,
			Level:     models.RiskYellow,
			AccountID: req.AccountID,
			Symbol:    req.Symbol,
			Message:   v.Message,
			Action:    "warn",
		}
		if v.Severity == "block" {
			alert.Level = models.RiskOrange
			alert.Action = "block"
		}
		if s.alertRepo != nil {
			_ = s.alertRepo.Create(ctx, alert)
		}
	}

	return result, nil
}

// evaluateRule 评估单条规则
func (s *RiskService) evaluateRule(rule *domain.RiskRule, req *domain.RiskCheckRequest) *domain.RiskViolation {
	// 根据规则类型进行检查
	switch rule.Type {
	case "position":
		return s.checkPosition(rule, req)
	case "capital":
		return s.checkCapital(rule, req)
	default:
		return nil
	}
}

func (s *RiskService) checkPosition(rule *domain.RiskRule, req *domain.RiskCheckRequest) *domain.RiskViolation {
	// 仓位检查逻辑 - 需要查询当前持仓
	s.log.Debug("checking position rule", "rule", rule.Name)
	return nil
}

func (s *RiskService) checkCapital(rule *domain.RiskRule, req *domain.RiskCheckRequest) *domain.RiskViolation {
	// 资金检查逻辑
	s.log.Debug("checking capital rule", "rule", rule.Name)
	return nil
}

// CreateRule 创建风控规则
func (s *RiskService) CreateRule(ctx context.Context, rule *domain.RiskRule) error {
	return s.ruleRepo.Create(ctx, rule)
}

// ListRules 列出风控规则
func (s *RiskService) ListRules(ctx context.Context, accountID string) ([]domain.RiskRule, error) {
	return s.ruleRepo.List(ctx, accountID)
}

// ListAlerts 列出告警
func (s *RiskService) ListAlerts(ctx context.Context, accountID string, resolved *bool) ([]domain.RiskAlert, error) {
	return s.alertRepo.List(ctx, accountID, resolved)
}
