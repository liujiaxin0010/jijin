package service

import (
	"context"
	"log/slog"
	"time"

	"github.com/quant-platform/server/internal/marketdata/connector"
	"github.com/quant-platform/server/internal/marketdata/domain"
	"github.com/quant-platform/server/pkg/models"
)

// MarketDataService 行情数据业务服务
type MarketDataService struct {
	klineRepo  domain.KlineRepository
	quoteRepo  domain.QuoteRepository
	symbolRepo domain.SymbolRepository
	connectors []connector.DataConnector
	log        *slog.Logger
}

// NewMarketDataService 创建行情数据服务
func NewMarketDataService(
	klineRepo domain.KlineRepository,
	quoteRepo domain.QuoteRepository,
	symbolRepo domain.SymbolRepository,
	connectors []connector.DataConnector,
	log *slog.Logger,
) *MarketDataService {
	return &MarketDataService{
		klineRepo:  klineRepo,
		quoteRepo:  quoteRepo,
		symbolRepo: symbolRepo,
		connectors: connectors,
		log:        log,
	}
}

// GetKlines 查询K线数据
func (s *MarketDataService) GetKlines(ctx context.Context, symbol string, tf models.Timeframe, start, end time.Time) ([]domain.Kline, error) {
	return s.klineRepo.Query(ctx, symbol, tf, start, end)
}

// GetLatestKlines 获取最新K线
func (s *MarketDataService) GetLatestKlines(ctx context.Context, symbol string, tf models.Timeframe, limit int) ([]domain.Kline, error) {
	return s.klineRepo.GetLatest(ctx, symbol, tf, limit)
}

// GetLatestQuote 获取最新行情
func (s *MarketDataService) GetLatestQuote(ctx context.Context, symbol string) (*domain.Quote, error) {
	return s.quoteRepo.GetLatest(ctx, symbol)
}

// GetBatchQuotes 批量获取行情
func (s *MarketDataService) GetBatchQuotes(ctx context.Context, symbols []string) ([]domain.Quote, error) {
	return s.quoteRepo.GetBatch(ctx, symbols)
}

// ListSymbols 查询标的列表
func (s *MarketDataService) ListSymbols(ctx context.Context, exchange models.Exchange, assetType models.AssetType) ([]domain.Symbol, error) {
	return s.symbolRepo.List(ctx, exchange, assetType)
}

// SearchSymbols 搜索标的
func (s *MarketDataService) SearchSymbols(ctx context.Context, keyword string) ([]domain.Symbol, error) {
	return s.symbolRepo.Search(ctx, keyword)
}
