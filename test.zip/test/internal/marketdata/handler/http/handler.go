package http

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/quant-platform/server/internal/marketdata/service"
	"github.com/quant-platform/server/pkg/models"
)

// Handler 行情数据HTTP处理器
type Handler struct {
	svc *service.MarketDataService
}

// NewHandler 创建HTTP处理器
func NewHandler(svc *service.MarketDataService) *Handler {
	return &Handler{svc: svc}
}

// RegisterRoutes 注册路由
func (h *Handler) RegisterRoutes(r *gin.RouterGroup) {
	g := r.Group("/market-data")
	g.GET("/klines", h.GetKlines)
	g.GET("/quote/:symbol", h.GetQuote)
	g.GET("/quotes", h.GetBatchQuotes)
	g.GET("/symbols", h.ListSymbols)
	g.GET("/symbols/search", h.SearchSymbols)
}

// GetKlines 查询K线
func (h *Handler) GetKlines(c *gin.Context) {
	symbol := c.Query("symbol")
	tf := c.DefaultQuery("timeframe", "1d")
	startStr := c.Query("start")
	endStr := c.Query("end")

	if symbol == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "symbol is required"})
		return
	}

	start, _ := time.Parse("2006-01-02", startStr)
	end, _ := time.Parse("2006-01-02", endStr)
	if end.IsZero() {
		end = time.Now()
	}
	if start.IsZero() {
		start = end.AddDate(0, -1, 0)
	}

	klines, err := h.svc.GetKlines(c.Request.Context(), symbol, models.Timeframe(tf), start, end)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": klines})
}

// GetQuote 获取单个标的实时行情
func (h *Handler) GetQuote(c *gin.Context) {
	symbol := c.Param("symbol")
	quote, err := h.svc.GetLatestQuote(c.Request.Context(), symbol)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": quote})
}

// GetBatchQuotes 批量获取行情
func (h *Handler) GetBatchQuotes(c *gin.Context) {
	symbols := c.QueryArray("symbols")
	if len(symbols) == 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "symbols is required"})
		return
	}
	quotes, err := h.svc.GetBatchQuotes(c.Request.Context(), symbols)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": quotes})
}

// ListSymbols 查询标的列表
func (h *Handler) ListSymbols(c *gin.Context) {
	exchange := c.Query("exchange")
	assetType := c.Query("asset_type")
	symbols, err := h.svc.ListSymbols(c.Request.Context(), models.Exchange(exchange), models.AssetType(assetType))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": symbols})
}

// SearchSymbols 搜索标的
func (h *Handler) SearchSymbols(c *gin.Context) {
	keyword := c.Query("q")
	if keyword == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "q is required"})
		return
	}
	symbols, err := h.svc.SearchSymbols(c.Request.Context(), keyword)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": symbols})
}
