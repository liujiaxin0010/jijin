package domain

import (
	"context"
	"time"

	"github.com/quant-platform/server/pkg/models"
)

// KlineRepository K线数据仓储接口
type KlineRepository interface {
	Save(ctx context.Context, klines []Kline) error
	Query(ctx context.Context, symbol string, tf models.Timeframe, start, end time.Time) ([]Kline, error)
	GetLatest(ctx context.Context, symbol string, tf models.Timeframe, limit int) ([]Kline, error)
}

// QuoteRepository 实时行情仓储接口
type QuoteRepository interface {
	SaveLatest(ctx context.Context, quote *Quote) error
	GetLatest(ctx context.Context, symbol string) (*Quote, error)
	GetBatch(ctx context.Context, symbols []string) ([]Quote, error)
}

// SymbolRepository 标的信息仓储接口
type SymbolRepository interface {
	Save(ctx context.Context, symbol *Symbol) error
	GetByCode(ctx context.Context, code string) (*Symbol, error)
	List(ctx context.Context, exchange models.Exchange, assetType models.AssetType) ([]Symbol, error)
	Search(ctx context.Context, keyword string) ([]Symbol, error)
}
