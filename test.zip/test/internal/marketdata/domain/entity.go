package domain

import (
	"time"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/pkg/models"
)

// Kline K线数据
type Kline struct {
	Symbol    string          `json:"symbol"`
	Exchange  models.Exchange `json:"exchange"`
	Timeframe models.Timeframe `json:"timeframe"`
	OpenTime  time.Time       `json:"open_time"`
	Open      decimal.Decimal `json:"open"`
	High      decimal.Decimal `json:"high"`
	Low       decimal.Decimal `json:"low"`
	Close     decimal.Decimal `json:"close"`
	Volume    int64           `json:"volume"`
	Turnover  decimal.Decimal `json:"turnover"`
	CloseTime time.Time       `json:"close_time"`
}

// Quote 实时行情
type Quote struct {
	Symbol     string          `json:"symbol"`
	Exchange   models.Exchange `json:"exchange"`
	LastPrice  decimal.Decimal `json:"last_price"`
	BidPrice   decimal.Decimal `json:"bid_price"`
	AskPrice   decimal.Decimal `json:"ask_price"`
	BidVolume  int64           `json:"bid_volume"`
	AskVolume  int64           `json:"ask_volume"`
	Volume     int64           `json:"volume"`
	Turnover   decimal.Decimal `json:"turnover"`
	OpenPrice  decimal.Decimal `json:"open_price"`
	HighPrice  decimal.Decimal `json:"high_price"`
	LowPrice   decimal.Decimal `json:"low_price"`
	PreClose   decimal.Decimal `json:"pre_close"`
	ChangeRate decimal.Decimal `json:"change_rate"`
	Timestamp  time.Time       `json:"timestamp"`
}

// Symbol 标的信息
type Symbol struct {
	Code      string          `json:"code"`
	Name      string          `json:"name"`
	Exchange  models.Exchange `json:"exchange"`
	AssetType models.AssetType `json:"asset_type"`
	ListDate  time.Time       `json:"list_date"`
	Status    string          `json:"status"` // ACTIVE, SUSPENDED, DELISTED
}

// DataSource 数据源
type DataSource struct {
	Name     string `json:"name"`
	Type     string `json:"type"` // tushare, eastmoney, wind
	Enabled  bool   `json:"enabled"`
	Priority int    `json:"priority"`
}
