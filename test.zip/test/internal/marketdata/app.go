package marketdata

import (
	"context"
	"fmt"
	"log/slog"
	"net"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/quant-platform/server/internal/marketdata/service"
	httpHandler "github.com/quant-platform/server/internal/marketdata/handler/http"
	"github.com/quant-platform/server/pkg/config"
	"github.com/quant-platform/server/pkg/middleware"
)

// App 行情数据服务应用
type App struct {
	cfg    *config.AppConfig
	log    *slog.Logger
	svc    *service.MarketDataService
	httpSrv *http.Server
}

// NewApp 创建应用实例
func NewApp(ctx context.Context, cfg *config.AppConfig, log *slog.Logger) (*App, error) {
	// TODO: 初始化数据库连接后注入真实仓储实现
	svc := service.NewMarketDataService(nil, nil, nil, nil, log)

	return &App{
		cfg: cfg,
		log: log,
		svc: svc,
	}, nil
}

// Run 启动服务
func (a *App) Run(ctx context.Context) error {
	router := gin.New()
	router.Use(middleware.Logger(a.log), middleware.Recovery(a.log), middleware.CORS())

	handler := httpHandler.NewHandler(a.svc)
	api := router.Group("/api/v1")
	handler.RegisterRoutes(api)

	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok", "service": "market-data"})
	})

	a.httpSrv = &http.Server{
		Addr:    fmt.Sprintf(":%d", a.cfg.HTTP.Port),
		Handler: router,
	}

	errCh := make(chan error, 1)
	go func() {
		a.log.Info("http server starting", "port", a.cfg.HTTP.Port)
		if err := a.httpSrv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			errCh <- err
		}
	}()

	select {
	case <-ctx.Done():
		a.log.Info("shutting down market-data service")
		return a.httpSrv.Shutdown(context.Background())
	case err := <-errCh:
		return fmt.Errorf("http server error: %w", err)
	}
}

// setupGRPC 预留gRPC服务启动
func (a *App) setupGRPC() (net.Listener, error) {
	lis, err := net.Listen("tcp", fmt.Sprintf(":%d", a.cfg.GRPC.Port))
	if err != nil {
		return nil, fmt.Errorf("listen grpc: %w", err)
	}
	return lis, nil
}
