package connector

import (
	"context"
	"time"

	"github.com/quant-platform/server/internal/marketdata/domain"
)

// DataConnector 数据源连接器接口
type DataConnector interface {
	Name() string
	FetchDailyKlines(ctx context.Context, symbol string, start, end time.Time) ([]domain.Kline, error)
	FetchRealtimeQuotes(ctx context.Context, symbols []string) ([]domain.Quote, error)
	FetchSymbolList(ctx context.Context) ([]domain.Symbol, error)
}
