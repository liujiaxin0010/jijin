package domain

import (
	"time"

	"github.com/shopspring/decimal"
)

// Portfolio 投资组合
type Portfolio struct {
	ID          string          `json:"id"`
	Name        string          `json:"name"`
	AccountID   string          `json:"account_id"`
	Description string          `json:"description"`
	TotalValue  decimal.Decimal `json:"total_value"`
	Cash        decimal.Decimal `json:"cash"`
	Status      string          `json:"status"` // active, paused, closed
	CreatedAt   time.Time       `json:"created_at"`
	UpdatedAt   time.Time       `json:"updated_at"`
}

// Allocation 组合配置
type Allocation struct {
	ID          string          `json:"id"`
	PortfolioID string          `json:"portfolio_id"`
	StrategyID  string          `json:"strategy_id"`
	Symbol      string          `json:"symbol"`
	TargetWeight decimal.Decimal `json:"target_weight"`
	ActualWeight decimal.Decimal `json:"actual_weight"`
	Quantity    int64           `json:"quantity"`
	MarketValue decimal.Decimal `json:"market_value"`
	UpdatedAt   time.Time       `json:"updated_at"`
}

// RebalanceTask 再平衡任务
type RebalanceTask struct {
	ID          string `json:"id"`
	PortfolioID string `json:"portfolio_id"`
	Method      string `json:"method"` // markowitz, risk_parity, equal_weight
	Status      string `json:"status"` // pending, running, completed, failed
	CreatedAt   time.Time `json:"created_at"`
}

// OptimizeRequest 组合优化请求
type OptimizeRequest struct {
	PortfolioID string   `json:"portfolio_id"`
	Method      string   `json:"method"`
	Symbols     []string `json:"symbols"`
	RiskFree    decimal.Decimal `json:"risk_free_rate"`
}
