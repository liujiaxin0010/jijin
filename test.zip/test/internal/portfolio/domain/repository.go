package domain

import "context"

// PortfolioRepository 组合仓储
type PortfolioRepository interface {
	Create(ctx context.Context, portfolio *Portfolio) error
	GetByID(ctx context.Context, id string) (*Portfolio, error)
	List(ctx context.Context, accountID string) ([]Portfolio, error)
	Update(ctx context.Context, portfolio *Portfolio) error
	Delete(ctx context.Context, id string) error
}

// AllocationRepository 配置仓储
type AllocationRepository interface {
	Create(ctx context.Context, alloc *Allocation) error
	List(ctx context.Context, portfolioID string) ([]Allocation, error)
	Update(ctx context.Context, alloc *Allocation) error
	Delete(ctx context.Context, id string) error
}
