package http

import (
	"github.com/gin-gonic/gin"
	"github.com/quant-platform/server/internal/portfolio/domain"
	"github.com/quant-platform/server/internal/portfolio/service"
)

// Handler 组合HTTP处理器
type Handler struct {
	svc *service.PortfolioService
}

// NewHandler 创建处理器
func NewHandler(svc *service.PortfolioService) *Handler {
	return &Handler{svc: svc}
}

// RegisterRoutes 注册路由
func (h *Handler) RegisterRoutes(r *gin.RouterGroup) {
	g := r.Group("/portfolios")

	g.POST("", h.createPortfolio)
	g.GET("", h.listPortfolios)
	g.GET("/:id", h.getPortfolio)
	g.GET("/:id/allocations", h.getAllocations)
	g.POST("/:id/optimize", h.optimize)
}

func (h *Handler) createPortfolio(c *gin.Context) {
	var p domain.Portfolio
	if err := c.ShouldBindJSON(&p); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}
	if err := h.svc.CreatePortfolio(c.Request.Context(), &p); err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(201, gin.H{"data": p})
}

func (h *Handler) listPortfolios(c *gin.Context) {
	portfolios, err := h.svc.ListPortfolios(c.Request.Context(), c.Query("account_id"))
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": portfolios})
}

func (h *Handler) getPortfolio(c *gin.Context) {
	p, err := h.svc.GetPortfolio(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(404, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": p})
}

func (h *Handler) getAllocations(c *gin.Context) {
	allocs, err := h.svc.GetAllocations(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": allocs})
}

func (h *Handler) optimize(c *gin.Context) {
	var req domain.OptimizeRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}
	req.PortfolioID = c.Param("id")
	allocs, err := h.svc.Optimize(c.Request.Context(), &req)
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": allocs})
}
