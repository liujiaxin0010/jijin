package service

import (
	"context"
	"fmt"
	"log/slog"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/internal/portfolio/domain"
)

// PortfolioService 组合管理服务
type PortfolioService struct {
	portfolioRepo  domain.PortfolioRepository
	allocationRepo domain.AllocationRepository
	log            *slog.Logger
}

// NewPortfolioService 创建组合服务
func NewPortfolioService(
	portfolioRepo domain.PortfolioRepository,
	allocationRepo domain.AllocationRepository,
	log *slog.Logger,
) *PortfolioService {
	return &PortfolioService{
		portfolioRepo:  portfolioRepo,
		allocationRepo: allocationRepo,
		log:            log,
	}
}

// CreatePortfolio 创建组合
func (s *PortfolioService) CreatePortfolio(ctx context.Context, p *domain.Portfolio) error {
	p.Status = "active"
	return s.portfolioRepo.Create(ctx, p)
}

// GetPortfolio 获取组合
func (s *PortfolioService) GetPortfolio(ctx context.Context, id string) (*domain.Portfolio, error) {
	return s.portfolioRepo.GetByID(ctx, id)
}

// ListPortfolios 列出组合
func (s *PortfolioService) ListPortfolios(ctx context.Context, accountID string) ([]domain.Portfolio, error) {
	return s.portfolioRepo.List(ctx, accountID)
}

// GetAllocations 获取组合配置
func (s *PortfolioService) GetAllocations(ctx context.Context, portfolioID string) ([]domain.Allocation, error) {
	return s.allocationRepo.List(ctx, portfolioID)
}

// UpdateAllocation 更新配置
func (s *PortfolioService) UpdateAllocation(ctx context.Context, alloc *domain.Allocation) error {
	return s.allocationRepo.Update(ctx, alloc)
}

// Optimize 组合优化
func (s *PortfolioService) Optimize(ctx context.Context, req *domain.OptimizeRequest) ([]domain.Allocation, error) {
	s.log.Info("optimizing portfolio", "portfolio_id", req.PortfolioID, "method", req.Method)

	switch req.Method {
	case "equal_weight":
		return s.equalWeightOptimize(req)
	case "markowitz":
		return s.markowitzOptimize(req)
	case "risk_parity":
		return s.riskParityOptimize(req)
	default:
		return nil, fmt.Errorf("unknown optimization method: %s", req.Method)
	}
}

// equalWeightOptimize 等权重优化
func (s *PortfolioService) equalWeightOptimize(req *domain.OptimizeRequest) ([]domain.Allocation, error) {
	n := len(req.Symbols)
	if n == 0 {
		return nil, fmt.Errorf("no symbols provided")
	}
	allocations := make([]domain.Allocation, 0, n)
	for _, symbol := range req.Symbols {
		allocations = append(allocations, domain.Allocation{
			PortfolioID:  req.PortfolioID,
			Symbol:       symbol,
			TargetWeight: decimal.NewFromInt(1).Div(decimal.NewFromInt(int64(n))),
		})
	}
	return allocations, nil
}

// markowitzOptimize Markowitz均值-方差优化
func (s *PortfolioService) markowitzOptimize(req *domain.OptimizeRequest) ([]domain.Allocation, error) {
	// TODO: 实现Markowitz优化
	// 1. 获取历史收益率数据
	// 2. 计算协方差矩阵
	// 3. 求解有效前沿
	// 4. 根据风险偏好选择最优组合
	s.log.Debug("markowitz optimization", "symbols", req.Symbols)
	return s.equalWeightOptimize(req) // 暂时回退到等权重
}

// riskParityOptimize 风险平价优化
func (s *PortfolioService) riskParityOptimize(req *domain.OptimizeRequest) ([]domain.Allocation, error) {
	// TODO: 实现风险平价优化
	// 1. 获取历史收益率数据
	// 2. 计算各资产波动率
	// 3. 按波动率倒数分配权重，使各资产风险贡献相等
	s.log.Debug("risk parity optimization", "symbols", req.Symbols)
	return s.equalWeightOptimize(req) // 暂时回退到等权重
}
