package http

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/quant-platform/server/internal/factor/service"
)

// Handler 因子服务HTTP处理器
type Handler struct {
	svc *service.FactorService
}

// NewHandler 创建HTTP处理器
func NewHandler(svc *service.FactorService) *Handler {
	return &Handler{svc: svc}
}

// RegisterRoutes 注册路由
func (h *Handler) RegisterRoutes(r *gin.RouterGroup) {
	g := r.Group("/factors")
	g.GET("", h.ListFactors)
	g.POST("/calculate", h.Calculate)
	g.GET("/values", h.QueryValues)
}

// ListFactors 列出因子
func (h *Handler) ListFactors(c *gin.Context) {
	category := c.Query("category")
	factors, err := h.svc.ListFactors(c.Request.Context(), category)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": factors})
}

// CalculateRequest 计算请求
type CalculateRequest struct {
	FactorName string `json:"factor_name" binding:"required"`
	Symbol     string `json:"symbol" binding:"required"`
	Start      string `json:"start"`
	End        string `json:"end"`
}

// Calculate 计算因子
func (h *Handler) Calculate(c *gin.Context) {
	var req CalculateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	end := time.Now()
	start := end.AddDate(0, -3, 0)
	if req.Start != "" {
		start, _ = time.Parse("2006-01-02", req.Start)
	}
	if req.End != "" {
		end, _ = time.Parse("2006-01-02", req.End)
	}

	values, err := h.svc.Calculate(c.Request.Context(), req.FactorName, req.Symbol, start, end)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": values})
}

// QueryValues 查询因子值
func (h *Handler) QueryValues(c *gin.Context) {
	factorID := c.Query("factor_id")
	symbol := c.Query("symbol")
	startStr := c.Query("start")
	endStr := c.Query("end")

	end := time.Now()
	start := end.AddDate(0, -1, 0)
	if startStr != "" {
		start, _ = time.Parse("2006-01-02", startStr)
	}
	if endStr != "" {
		end, _ = time.Parse("2006-01-02", endStr)
	}

	values, err := h.svc.QueryValues(c.Request.Context(), factorID, symbol, start, end)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": values})
}
