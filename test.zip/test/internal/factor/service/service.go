package service

import (
	"context"
	"fmt"
	"log/slog"
	"time"

	"github.com/quant-platform/server/internal/factor/calculator"
	"github.com/quant-platform/server/internal/factor/domain"
)

// FactorService 因子业务服务
type FactorService struct {
	factorRepo domain.FactorRepository
	valueRepo  domain.FactorValueRepository
	registry   *calculator.Registry
	log        *slog.Logger
}

// NewFactorService 创建因子服务
func NewFactorService(
	factorRepo domain.FactorRepository,
	valueRepo domain.FactorValueRepository,
	registry *calculator.Registry,
	log *slog.Logger,
) *FactorService {
	return &FactorService{
		factorRepo: factorRepo,
		valueRepo:  valueRepo,
		registry:   registry,
		log:        log,
	}
}

// Calculate 计算指定因子
func (s *FactorService) Calculate(ctx context.Context, factorName, symbol string, start, end time.Time) ([]domain.FactorValue, error) {
	calc, ok := s.registry.Get(factorName)
	if !ok {
		return nil, fmt.Errorf("factor calculator not found: %s", factorName)
	}

	values, err := calc.Calculate(ctx, symbol, start, end)
	if err != nil {
		return nil, err
	}

	if s.valueRepo != nil && len(values) > 0 {
		if err := s.valueRepo.SaveBatch(ctx, values); err != nil {
			s.log.Error("save factor values failed", "factor", factorName, "error", err)
		}
	}

	return values, nil
}

// ListFactors 列出所有因子
func (s *FactorService) ListFactors(ctx context.Context, category string) ([]domain.Factor, error) {
	if s.factorRepo != nil {
		return s.factorRepo.List(ctx, category)
	}
	// 从注册表返回
	calcs := s.registry.List()
	factors := make([]domain.Factor, 0, len(calcs))
	for _, c := range calcs {
		factors = append(factors, domain.Factor{
			Name:     c.Name(),
			Category: c.Category(),
		})
	}
	return factors, nil
}

// QueryValues 查询因子值
func (s *FactorService) QueryValues(ctx context.Context, factorID, symbol string, start, end time.Time) ([]domain.FactorValue, error) {
	return s.valueRepo.Query(ctx, factorID, symbol, start, end)
}
