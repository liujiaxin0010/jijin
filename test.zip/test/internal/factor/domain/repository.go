package domain

import (
	"context"
	"time"
)

// FactorRepository 因子元数据仓储
type FactorRepository interface {
	Save(ctx context.Context, factor *Factor) error
	GetByID(ctx context.Context, id string) (*Factor, error)
	List(ctx context.Context, category string) ([]Factor, error)
	Delete(ctx context.Context, id string) error
}

// FactorValueRepository 因子值仓储
type FactorValueRepository interface {
	SaveBatch(ctx context.Context, values []FactorValue) error
	Query(ctx context.Context, factorID, symbol string, start, end time.Time) ([]FactorValue, error)
	GetLatest(ctx context.Context, factorID, symbol string) (*FactorValue, error)
}
