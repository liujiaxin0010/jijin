package domain

import (
	"time"

	"github.com/shopspring/decimal"
)

// Factor 因子定义
type Factor struct {
	ID          string    `json:"id"`
	Name        string    `json:"name"`
	Category    string    `json:"category"` // technical, fundamental, volume_price, sentiment
	Description string    `json:"description"`
	Formula     string    `json:"formula"`
	Params      map[string]interface{} `json:"params"`
	CreatedAt   time.Time `json:"created_at"`
}

// FactorValue 因子值
type FactorValue struct {
	FactorID  string          `json:"factor_id"`
	Symbol    string          `json:"symbol"`
	Date      time.Time       `json:"date"`
	Value     decimal.Decimal `json:"value"`
	UpdatedAt time.Time       `json:"updated_at"`
}

// FactorCategory 因子分类
const (
	CategoryTechnical   = "technical"
	CategoryFundamental = "fundamental"
	CategoryVolumePrice = "volume_price"
	CategorySentiment   = "sentiment"
	CategoryMomentum    = "momentum"
	CategoryValue       = "value"
	CategoryQuality     = "quality"
	CategoryVolatility  = "volatility"
)
