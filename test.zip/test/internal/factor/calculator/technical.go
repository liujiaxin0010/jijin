package calculator

import (
	"context"
	"fmt"
	"math"
	"time"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/internal/factor/domain"
	mktDomain "github.com/quant-platform/server/internal/marketdata/domain"
	"github.com/quant-platform/server/pkg/models"
)

// KlineProvider K线数据提供接口
type KlineProvider interface {
	Query(ctx context.Context, symbol string, tf models.Timeframe, start, end time.Time) ([]mktDomain.Kline, error)
}

// TechnicalCalculator 技术因子计算器
type TechnicalCalculator struct {
	factorName string
	category   string
	klines     KlineProvider
	calcFn     func(klines []mktDomain.Kline) []decimal.Decimal
}

func (t *TechnicalCalculator) Name() string     { return t.factorName }
func (t *TechnicalCalculator) Category() string  { return t.category }

func (t *TechnicalCalculator) Calculate(ctx context.Context, symbol string, start, end time.Time) ([]domain.FactorValue, error) {
	klines, err := t.klines.Query(ctx, symbol, models.Timeframe1d, start, end)
	if err != nil {
		return nil, err
	}
	if len(klines) == 0 {
		return nil, nil
	}

	values := t.calcFn(klines)
	result := make([]domain.FactorValue, 0, len(values))
	for i, v := range values {
		if v.Equal(decimal.NewFromInt(-999)) {
			continue // skip invalid
		}
		result = append(result, domain.FactorValue{
			FactorID: t.factorName,
			Symbol:   symbol,
			Date:     klines[i].OpenTime,
			Value:    v,
		})
	}
	return result, nil
}

// NewMA 移动平均线因子
func NewMA(period int, provider KlineProvider) *TechnicalCalculator {
	invalid := decimal.NewFromInt(-999)
	return &TechnicalCalculator{
		factorName: fmt.Sprintf("MA_%d", period),
		category:   domain.CategoryTechnical,
		klines:     provider,
		calcFn: func(klines []mktDomain.Kline) []decimal.Decimal {
			result := make([]decimal.Decimal, len(klines))
			for i := range klines {
				if i < period-1 {
					result[i] = invalid
					continue
				}
				sum := decimal.Zero
				for j := i - period + 1; j <= i; j++ {
					sum = sum.Add(klines[j].Close)
				}
				result[i] = sum.Div(decimal.NewFromInt(int64(period)))
			}
			return result
		},
	}
}

// NewRSI RSI因子
func NewRSI(period int, provider KlineProvider) *TechnicalCalculator {
	invalid := decimal.NewFromInt(-999)
	return &TechnicalCalculator{
		factorName: fmt.Sprintf("RSI_%d", period),
		category:   domain.CategoryTechnical,
		klines:     provider,
		calcFn: func(klines []mktDomain.Kline) []decimal.Decimal {
			result := make([]decimal.Decimal, len(klines))
			if len(klines) < period+1 {
				for i := range result {
					result[i] = invalid
				}
				return result
			}

			gains := make([]float64, len(klines))
			losses := make([]float64, len(klines))
			for i := 1; i < len(klines); i++ {
				diff, _ := klines[i].Close.Sub(klines[i-1].Close).Float64()
				if diff > 0 {
					gains[i] = diff
				} else {
					losses[i] = math.Abs(diff)
				}
			}

			var avgGain, avgLoss float64
			for i := 1; i <= period; i++ {
				avgGain += gains[i]
				avgLoss += losses[i]
			}
			avgGain /= float64(period)
			avgLoss /= float64(period)

			for i := 0; i < period; i++ {
				result[i] = invalid
			}

			if avgLoss == 0 {
				result[period] = decimal.NewFromInt(100)
			} else {
				rs := avgGain / avgLoss
				result[period] = decimal.NewFromFloat(100 - 100/(1+rs))
			}

			for i := period + 1; i < len(klines); i++ {
				avgGain = (avgGain*float64(period-1) + gains[i]) / float64(period)
				avgLoss = (avgLoss*float64(period-1) + losses[i]) / float64(period)
				if avgLoss == 0 {
					result[i] = decimal.NewFromInt(100)
				} else {
					rs := avgGain / avgLoss
					result[i] = decimal.NewFromFloat(100 - 100/(1+rs))
				}
			}
			return result
		},
	}
}
