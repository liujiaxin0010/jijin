package calculator

import (
	"context"
	"time"

	"github.com/quant-platform/server/internal/factor/domain"
)

// Calculator 因子计算器接口
type Calculator interface {
	Name() string
	Category() string
	Calculate(ctx context.Context, symbol string, start, end time.Time) ([]domain.FactorValue, error)
}

// Registry 因子计算器注册表
type Registry struct {
	calculators map[string]Calculator
}

// NewRegistry 创建注册表
func NewRegistry() *Registry {
	return &Registry{
		calculators: make(map[string]Calculator),
	}
}

// Register 注册计算器
func (r *Registry) Register(calc Calculator) {
	r.calculators[calc.Name()] = calc
}

// Get 获取计算器
func (r *Registry) Get(name string) (Calculator, bool) {
	c, ok := r.calculators[name]
	return c, ok
}

// List 列出所有计算器
func (r *Registry) List() []Calculator {
	result := make([]Calculator, 0, len(r.calculators))
	for _, c := range r.calculators {
		result = append(result, c)
	}
	return result
}
