package domain

import (
	"time"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/pkg/models"
)

// Strategy 策略
type Strategy struct {
	ID          string                `json:"id"`
	Name        string                `json:"name"`
	Type        string                `json:"type"` // dual_ma, macd, rsi, momentum, custom
	Description string                `json:"description"`
	AccountID   string                `json:"account_id"`
	Status      models.StrategyStatus `json:"status"`
	Version     int                   `json:"version"`
	Params      map[string]string     `json:"params"`
	Symbols     []string              `json:"symbols"`
	Timeframe   models.Timeframe      `json:"timeframe"`
	CreatedAt   time.Time             `json:"created_at"`
	UpdatedAt   time.Time             `json:"updated_at"`
}

// StrategyVersion 策略版本
type StrategyVersion struct {
	ID         string            `json:"id"`
	StrategyID string            `json:"strategy_id"`
	Version    int               `json:"version"`
	Params     map[string]string `json:"params"`
	Changelog  string            `json:"changelog"`
	CreatedAt  time.Time         `json:"created_at"`
}

// Signal 交易信号
type Signal struct {
	ID         string          `json:"id"`
	StrategyID string          `json:"strategy_id"`
	Symbol     string          `json:"symbol"`
	Side       models.OrderSide `json:"side"`
	Quantity   int64           `json:"quantity"`
	Price      decimal.Decimal `json:"price"`
	Reason     string          `json:"reason"`
	Strength   decimal.Decimal `json:"strength"` // 信号强度 0-1
	CreatedAt  time.Time       `json:"created_at"`
}

// StrategyTemplate 策略模板
type StrategyTemplate struct {
	Type        string            `json:"type"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	DefaultParams map[string]string `json:"default_params"`
}

// ExecutionContext 策略执行上下文
type ExecutionContext struct {
	Strategy  *Strategy
	AccountID string
	Symbols   []string
	Params    map[string]string
}
