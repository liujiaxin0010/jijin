package domain

import "context"

// StrategyRepository 策略仓储
type StrategyRepository interface {
	Create(ctx context.Context, strategy *Strategy) error
	GetByID(ctx context.Context, id string) (*Strategy, error)
	List(ctx context.Context, accountID string) ([]Strategy, error)
	Update(ctx context.Context, strategy *Strategy) error
	Delete(ctx context.Context, id string) error
	UpdateStatus(ctx context.Context, id string, status string) error
}

// StrategyVersionRepository 策略版本仓储
type StrategyVersionRepository interface {
	Create(ctx context.Context, version *StrategyVersion) error
	List(ctx context.Context, strategyID string) ([]StrategyVersion, error)
	GetByVersion(ctx context.Context, strategyID string, version int) (*StrategyVersion, error)
}

// SignalRepository 信号仓储
type SignalRepository interface {
	Create(ctx context.Context, signal *Signal) error
	List(ctx context.Context, strategyID string, limit int) ([]Signal, error)
}
