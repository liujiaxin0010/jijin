package engine

import (
	"context"

	"github.com/quant-platform/server/internal/strategy/domain"
)

// StrategyEngine 策略引擎接口
type StrategyEngine interface {
	// Name 策略名称
	Name() string
	// Type 策略类型
	Type() string
	// Description 策略描述
	Description() string
	// DefaultParams 默认参数
	DefaultParams() map[string]string
	// Execute 执行策略，生成信号
	Execute(ctx context.Context, execCtx *domain.ExecutionContext) ([]domain.Signal, error)
}

// Registry 策略引擎注册表
type Registry struct {
	engines map[string]StrategyEngine
}

// NewRegistry 创建注册表
func NewRegistry() *Registry {
	return &Registry{engines: make(map[string]StrategyEngine)}
}

// Register 注册策略引擎
func (r *Registry) Register(engine StrategyEngine) {
	r.engines[engine.Type()] = engine
}

// Get 获取策略引擎
func (r *Registry) Get(strategyType string) (StrategyEngine, bool) {
	e, ok := r.engines[strategyType]
	return e, ok
}

// List 列出所有已注册的策略模板
func (r *Registry) List() []domain.StrategyTemplate {
	templates := make([]domain.StrategyTemplate, 0, len(r.engines))
	for _, e := range r.engines {
		templates = append(templates, domain.StrategyTemplate{
			Type:          e.Type(),
			Name:          e.Name(),
			Description:   e.Description(),
			DefaultParams: e.DefaultParams(),
		})
	}
	return templates
}
