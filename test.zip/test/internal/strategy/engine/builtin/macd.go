package builtin

import (
	"context"
	"log/slog"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/internal/strategy/domain"
	"github.com/quant-platform/server/internal/strategy/engine"
	"github.com/quant-platform/server/pkg/models"
)

// MACDStrategy MACD策略
// 基于MACD指标的金叉死叉信号
type MACDStrategy struct {
	log *slog.Logger
}

// NewMACDStrategy 创建MACD策略
func NewMACDStrategy(log *slog.Logger) engine.StrategyEngine {
	return &MACDStrategy{log: log}
}

func (s *MACDStrategy) Name() string        { return "MACD策略" }
func (s *MACDStrategy) Type() string        { return "macd" }
func (s *MACDStrategy) Description() string { return "MACD金叉买入，死叉卖出" }

func (s *MACDStrategy) DefaultParams() map[string]string {
	return map[string]string{
		"fast_period":   "12",
		"slow_period":   "26",
		"signal_period": "9",
		"quantity":      "100",
	}
}

func (s *MACDStrategy) Execute(ctx context.Context, execCtx *domain.ExecutionContext) ([]domain.Signal, error) {
	s.log.Info("executing MACD strategy",
		"strategy_id", execCtx.Strategy.ID,
		"symbols", execCtx.Symbols,
	)

	// TODO: 接入行情数据获取K线，计算MACD指标
	// 1. 计算快线EMA和慢线EMA
	// 2. 计算DIF = 快线EMA - 慢线EMA
	// 3. 计算DEA = DIF的EMA
	// 4. 检测DIF上穿/下穿DEA
	var signals []domain.Signal

	for _, symbol := range execCtx.Symbols {
		signal := domain.Signal{
			StrategyID: execCtx.Strategy.ID,
			Symbol:     symbol,
			Side:       models.OrderBuy,
			Quantity:   100,
			Price:      decimal.NewFromFloat(0),
			Reason:     "macd_cross",
			Strength:   decimal.NewFromFloat(0.5),
		}
		_ = signal
	}

	return signals, nil
}
