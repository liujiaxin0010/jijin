package builtin

import (
	"context"
	"log/slog"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/internal/strategy/domain"
	"github.com/quant-platform/server/internal/strategy/engine"
	"github.com/quant-platform/server/pkg/models"
)

// MomentumStrategy 动量策略
// 基于价格动量进行趋势跟踪
type MomentumStrategy struct {
	log *slog.Logger
}

// NewMomentumStrategy 创建动量策略
func NewMomentumStrategy(log *slog.Logger) engine.StrategyEngine {
	return &MomentumStrategy{log: log}
}

func (s *MomentumStrategy) Name() string        { return "动量策略" }
func (s *MomentumStrategy) Type() string        { return "momentum" }
func (s *MomentumStrategy) Description() string { return "基于价格动量的趋势跟踪策略" }

func (s *MomentumStrategy) DefaultParams() map[string]string {
	return map[string]string{
		"lookback_period": "20",
		"threshold":       "0.05",
		"quantity":        "100",
	}
}

func (s *MomentumStrategy) Execute(ctx context.Context, execCtx *domain.ExecutionContext) ([]domain.Signal, error) {
	s.log.Info("executing momentum strategy",
		"strategy_id", execCtx.Strategy.ID,
		"symbols", execCtx.Symbols,
	)

	// TODO: 接入行情数据获取K线，计算动量指标
	// 1. 计算lookback期间的收益率
	// 2. 收益率 > threshold → 买入（趋势延续）
	// 3. 收益率 < -threshold → 卖出
	var signals []domain.Signal

	for _, symbol := range execCtx.Symbols {
		signal := domain.Signal{
			StrategyID: execCtx.Strategy.ID,
			Symbol:     symbol,
			Side:       models.OrderBuy,
			Quantity:   100,
			Price:      decimal.NewFromFloat(0),
			Reason:     "momentum_positive",
			Strength:   decimal.NewFromFloat(0.5),
		}
		_ = signal
	}

	return signals, nil
}
