package builtin

import (
	"context"
	"log/slog"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/internal/strategy/domain"
	"github.com/quant-platform/server/internal/strategy/engine"
	"github.com/quant-platform/server/pkg/models"
)

// DualMAStrategy 双均线策略
// 当短期均线上穿长期均线时买入，下穿时卖出
type DualMAStrategy struct {
	log *slog.Logger
}

// NewDualMAStrategy 创建双均线策略
func NewDualMAStrategy(log *slog.Logger) engine.StrategyEngine {
	return &DualMAStrategy{log: log}
}

func (s *DualMAStrategy) Name() string        { return "双均线策略" }
func (s *DualMAStrategy) Type() string        { return "dual_ma" }
func (s *DualMAStrategy) Description() string { return "短期均线上穿长期均线买入，下穿卖出" }

func (s *DualMAStrategy) DefaultParams() map[string]string {
	return map[string]string{
		"short_period": "5",
		"long_period":  "20",
		"quantity":     "100",
	}
}

func (s *DualMAStrategy) Execute(ctx context.Context, execCtx *domain.ExecutionContext) ([]domain.Signal, error) {
	s.log.Info("executing dual MA strategy",
		"strategy_id", execCtx.Strategy.ID,
		"symbols", execCtx.Symbols,
	)

	// TODO: 接入行情数据服务获取K线，计算均线交叉
	// 当前为框架实现，实际需要：
	// 1. 获取历史K线数据
	// 2. 计算短期和长期移动平均线
	// 3. 检测金叉/死叉信号
	var signals []domain.Signal

	for _, symbol := range execCtx.Symbols {
		signal := domain.Signal{
			StrategyID: execCtx.Strategy.ID,
			Symbol:     symbol,
			Side:       models.OrderBuy,
			Quantity:   100,
			Price:      decimal.NewFromFloat(0),
			Reason:     "dual_ma_cross",
			Strength:   decimal.NewFromFloat(0.5),
		}
		_ = signal // placeholder
	}

	return signals, nil
}
