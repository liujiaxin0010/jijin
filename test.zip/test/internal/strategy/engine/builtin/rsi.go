package builtin

import (
	"context"
	"log/slog"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/internal/strategy/domain"
	"github.com/quant-platform/server/internal/strategy/engine"
	"github.com/quant-platform/server/pkg/models"
)

// RSIStrategy RSI策略
// RSI超卖买入，超买卖出
type RSIStrategy struct {
	log *slog.Logger
}

// NewRSIStrategy 创建RSI策略
func NewRSIStrategy(log *slog.Logger) engine.StrategyEngine {
	return &RSIStrategy{log: log}
}

func (s *RSIStrategy) Name() string        { return "RSI策略" }
func (s *RSIStrategy) Type() string        { return "rsi" }
func (s *RSIStrategy) Description() string { return "RSI超卖区买入，超买区卖出" }

func (s *RSIStrategy) DefaultParams() map[string]string {
	return map[string]string{
		"period":         "14",
		"oversold":       "30",
		"overbought":     "70",
		"quantity":       "100",
	}
}

func (s *RSIStrategy) Execute(ctx context.Context, execCtx *domain.ExecutionContext) ([]domain.Signal, error) {
	s.log.Info("executing RSI strategy",
		"strategy_id", execCtx.Strategy.ID,
		"symbols", execCtx.Symbols,
	)

	// TODO: 接入行情数据获取K线，计算RSI指标
	// 1. 计算RSI值
	// 2. RSI < oversold → 买入信号
	// 3. RSI > overbought → 卖出信号
	var signals []domain.Signal

	for _, symbol := range execCtx.Symbols {
		signal := domain.Signal{
			StrategyID: execCtx.Strategy.ID,
			Symbol:     symbol,
			Side:       models.OrderBuy,
			Quantity:   100,
			Price:      decimal.NewFromFloat(0),
			Reason:     "rsi_oversold",
			Strength:   decimal.NewFromFloat(0.5),
		}
		_ = signal
	}

	return signals, nil
}
