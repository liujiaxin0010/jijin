package http

import (
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/quant-platform/server/internal/strategy/domain"
	"github.com/quant-platform/server/internal/strategy/service"
)

// Handler 策略HTTP处理器
type Handler struct {
	svc *service.StrategyService
}

// NewHandler 创建处理器
func NewHandler(svc *service.StrategyService) *Handler {
	return &Handler{svc: svc}
}

// RegisterRoutes 注册路由
func (h *Handler) RegisterRoutes(r *gin.RouterGroup) {
	g := r.Group("/strategies")

	g.POST("", h.createStrategy)
	g.GET("", h.listStrategies)
	g.GET("/:id", h.getStrategy)
	g.PUT("/:id", h.updateStrategy)
	g.POST("/:id/execute", h.executeStrategy)
	g.GET("/:id/signals", h.listSignals)
	g.GET("/templates", h.listTemplates)
}

func (h *Handler) createStrategy(c *gin.Context) {
	var strategy domain.Strategy
	if err := c.ShouldBindJSON(&strategy); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}
	if err := h.svc.CreateStrategy(c.Request.Context(), &strategy); err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(201, gin.H{"data": strategy})
}

func (h *Handler) getStrategy(c *gin.Context) {
	strategy, err := h.svc.GetStrategy(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(404, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": strategy})
}

func (h *Handler) listStrategies(c *gin.Context) {
	strategies, err := h.svc.ListStrategies(c.Request.Context(), c.Query("account_id"))
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": strategies})
}

func (h *Handler) updateStrategy(c *gin.Context) {
	var strategy domain.Strategy
	if err := c.ShouldBindJSON(&strategy); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}
	strategy.ID = c.Param("id")
	if err := h.svc.UpdateStrategy(c.Request.Context(), &strategy); err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": strategy})
}

func (h *Handler) executeStrategy(c *gin.Context) {
	signals, err := h.svc.ExecuteStrategy(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": signals})
}

func (h *Handler) listSignals(c *gin.Context) {
	limit := 50
	if l := c.Query("limit"); l != "" {
		if v, err := strconv.Atoi(l); err == nil && v > 0 {
			limit = v
		}
	}
	signals, err := h.svc.ListSignals(c.Request.Context(), c.Param("id"), limit)
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": signals})
}

func (h *Handler) listTemplates(c *gin.Context) {
	templates := h.svc.ListTemplates()
	c.JSON(200, gin.H{"data": templates})
}
