package service

import (
	"context"
	"fmt"
	"log/slog"

	"github.com/quant-platform/server/internal/strategy/domain"
	"github.com/quant-platform/server/internal/strategy/engine"
)

// StrategyService 策略业务服务
type StrategyService struct {
	strategyRepo domain.StrategyRepository
	versionRepo  domain.StrategyVersionRepository
	signalRepo   domain.SignalRepository
	registry     *engine.Registry
	log          *slog.Logger
}

// NewStrategyService 创建策略服务
func NewStrategyService(
	strategyRepo domain.StrategyRepository,
	versionRepo domain.StrategyVersionRepository,
	signalRepo domain.SignalRepository,
	registry *engine.Registry,
	log *slog.Logger,
) *StrategyService {
	return &StrategyService{
		strategyRepo: strategyRepo,
		versionRepo:  versionRepo,
		signalRepo:   signalRepo,
		registry:     registry,
		log:          log,
	}
}

// CreateStrategy 创建策略
func (s *StrategyService) CreateStrategy(ctx context.Context, strategy *domain.Strategy) error {
	if _, ok := s.registry.Get(strategy.Type); !ok {
		return fmt.Errorf("unknown strategy type: %s", strategy.Type)
	}
	return s.strategyRepo.Create(ctx, strategy)
}

// GetStrategy 获取策略
func (s *StrategyService) GetStrategy(ctx context.Context, id string) (*domain.Strategy, error) {
	return s.strategyRepo.GetByID(ctx, id)
}

// ListStrategies 列出策略
func (s *StrategyService) ListStrategies(ctx context.Context, accountID string) ([]domain.Strategy, error) {
	return s.strategyRepo.List(ctx, accountID)
}

// UpdateStrategy 更新策略
func (s *StrategyService) UpdateStrategy(ctx context.Context, strategy *domain.Strategy) error {
	return s.strategyRepo.Update(ctx, strategy)
}

// ExecuteStrategy 执行策略生成信号
func (s *StrategyService) ExecuteStrategy(ctx context.Context, id string) ([]domain.Signal, error) {
	strategy, err := s.strategyRepo.GetByID(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("get strategy: %w", err)
	}

	eng, ok := s.registry.Get(strategy.Type)
	if !ok {
		return nil, fmt.Errorf("engine not found for type: %s", strategy.Type)
	}

	execCtx := &domain.ExecutionContext{
		Strategy:  strategy,
		AccountID: strategy.AccountID,
		Symbols:   strategy.Symbols,
		Params:    strategy.Params,
	}

	signals, err := eng.Execute(ctx, execCtx)
	if err != nil {
		return nil, fmt.Errorf("execute strategy: %w", err)
	}

	// 持久化信号
	for i := range signals {
		if s.signalRepo != nil {
			_ = s.signalRepo.Create(ctx, &signals[i])
		}
	}

	s.log.Info("strategy executed", "id", id, "signals", len(signals))
	return signals, nil
}

// ListTemplates 列出策略模板
func (s *StrategyService) ListTemplates() []domain.StrategyTemplate {
	return s.registry.List()
}

// ListSignals 列出策略信号
func (s *StrategyService) ListSignals(ctx context.Context, strategyID string, limit int) ([]domain.Signal, error) {
	return s.signalRepo.List(ctx, strategyID, limit)
}
