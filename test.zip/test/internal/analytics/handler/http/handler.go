package http

import (
	"github.com/gin-gonic/gin"
	"github.com/quant-platform/server/internal/analytics/service"
)

// Handler 绩效分析HTTP处理器
type Handler struct {
	svc *service.AnalyticsService
}

// NewHandler 创建处理器
func NewHandler(svc *service.AnalyticsService) *Handler {
	return &Handler{svc: svc}
}

// RegisterRoutes 注册路由
func (h *Handler) RegisterRoutes(r *gin.RouterGroup) {
	g := r.Group("/analytics")

	g.POST("/reports", h.generateReport)
	g.GET("/reports", h.listReports)
	g.GET("/reports/:id", h.getReport)
	g.GET("/reports/:id/attribution", h.getAttribution)
}

func (h *Handler) generateReport(c *gin.Context) {
	accountID := c.Query("account_id")
	strategyID := c.Query("strategy_id")
	period := c.DefaultQuery("period", "monthly")

	report, err := h.svc.GenerateReport(c.Request.Context(), accountID, strategyID, period)
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(201, gin.H{"data": report})
}

func (h *Handler) listReports(c *gin.Context) {
	reports, err := h.svc.ListReports(c.Request.Context(), c.Query("account_id"), c.Query("period"))
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": reports})
}

func (h *Handler) getReport(c *gin.Context) {
	report, err := h.svc.GetReport(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(404, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": report})
}

func (h *Handler) getAttribution(c *gin.Context) {
	attrs, err := h.svc.GetAttribution(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": attrs})
}
