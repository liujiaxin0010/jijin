package service

import (
	"context"
	"fmt"
	"log/slog"

	"github.com/quant-platform/server/internal/analytics/domain"
)

// AnalyticsService 绩效分析服务
type AnalyticsService struct {
	reportRepo domain.PerformanceReportRepository
	attrRepo   domain.AttributionRepository
	log        *slog.Logger
}

// NewAnalyticsService 创建绩效分析服务
func NewAnalyticsService(
	reportRepo domain.PerformanceReportRepository,
	attrRepo domain.AttributionRepository,
	log *slog.Logger,
) *AnalyticsService {
	return &AnalyticsService{
		reportRepo: reportRepo,
		attrRepo:   attrRepo,
		log:        log,
	}
}

// GenerateReport 生成绩效报告
func (s *AnalyticsService) GenerateReport(ctx context.Context, accountID, strategyID, period string) (*domain.PerformanceReport, error) {
	s.log.Info("generating performance report",
		"account_id", accountID,
		"strategy_id", strategyID,
		"period", period,
	)

	// TODO: 从交易记录和权益曲线计算绩效指标
	report := &domain.PerformanceReport{
		AccountID:  accountID,
		StrategyID: strategyID,
		Period:     period,
	}

	if s.reportRepo != nil {
		if err := s.reportRepo.Create(ctx, report); err != nil {
			return nil, fmt.Errorf("create report: %w", err)
		}
	}
	return report, nil
}

// GetReport 获取绩效报告
func (s *AnalyticsService) GetReport(ctx context.Context, id string) (*domain.PerformanceReport, error) {
	return s.reportRepo.GetByID(ctx, id)
}

// ListReports 列出绩效报告
func (s *AnalyticsService) ListReports(ctx context.Context, accountID, period string) ([]domain.PerformanceReport, error) {
	return s.reportRepo.List(ctx, accountID, period)
}

// GetAttribution 获取归因分析
func (s *AnalyticsService) GetAttribution(ctx context.Context, reportID string) ([]domain.Attribution, error) {
	return s.attrRepo.ListByReportID(ctx, reportID)
}
