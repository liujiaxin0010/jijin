package domain

import (
	"time"

	"github.com/shopspring/decimal"
)

// PerformanceReport 绩效报告
type PerformanceReport struct {
	ID          string          `json:"id"`
	AccountID   string          `json:"account_id"`
	StrategyID  string          `json:"strategy_id"`
	Period      string          `json:"period"` // daily, weekly, monthly, yearly
	StartDate   time.Time       `json:"start_date"`
	EndDate     time.Time       `json:"end_date"`
	TotalReturn decimal.Decimal `json:"total_return"`
	AnnualReturn decimal.Decimal `json:"annual_return"`
	SharpeRatio decimal.Decimal `json:"sharpe_ratio"`
	MaxDrawdown decimal.Decimal `json:"max_drawdown"`
	Volatility  decimal.Decimal `json:"volatility"`
	WinRate     decimal.Decimal `json:"win_rate"`
	CreatedAt   time.Time       `json:"created_at"`
}

// Attribution 归因分析
type Attribution struct {
	ID         string          `json:"id"`
	ReportID   string          `json:"report_id"`
	Type       string          `json:"type"` // brinson, factor
	Category   string          `json:"category"`
	Name       string          `json:"name"`
	Return     decimal.Decimal `json:"return"`
	Weight     decimal.Decimal `json:"weight"`
	Contribution decimal.Decimal `json:"contribution"`
}
