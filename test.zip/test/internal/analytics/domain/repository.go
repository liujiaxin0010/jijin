package domain

import "context"

// PerformanceReportRepository 绩效报告仓储
type PerformanceReportRepository interface {
	Create(ctx context.Context, report *PerformanceReport) error
	GetByID(ctx context.Context, id string) (*PerformanceReport, error)
	List(ctx context.Context, accountID string, period string) ([]PerformanceReport, error)
}

// AttributionRepository 归因仓储
type AttributionRepository interface {
	Create(ctx context.Context, attr *Attribution) error
	ListByReportID(ctx context.Context, reportID string) ([]Attribution, error)
}
