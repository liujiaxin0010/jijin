package domain

import (
	"time"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/pkg/models"
)

// BacktestTask 回测任务
type BacktestTask struct {
	ID         string            `json:"id"`
	StrategyID string            `json:"strategy_id"`
	AccountID  string            `json:"account_id"`
	Name       string            `json:"name"`
	Status     string            `json:"status"` // pending, running, completed, failed
	Symbols    []string          `json:"symbols"`
	Timeframe  models.Timeframe  `json:"timeframe"`
	StartDate  time.Time         `json:"start_date"`
	EndDate    time.Time         `json:"end_date"`
	InitCash   decimal.Decimal   `json:"init_cash"`
	Commission decimal.Decimal   `json:"commission"` // 手续费率
	Slippage   decimal.Decimal   `json:"slippage"`   // 滑点
	Params     map[string]string `json:"params"`
	CreatedAt  time.Time         `json:"created_at"`
	UpdatedAt  time.Time         `json:"updated_at"`
}

// BacktestResult 回测结果
type BacktestResult struct {
	ID            string          `json:"id"`
	TaskID        string          `json:"task_id"`
	TotalReturn   decimal.Decimal `json:"total_return"`
	AnnualReturn  decimal.Decimal `json:"annual_return"`
	SharpeRatio   decimal.Decimal `json:"sharpe_ratio"`
	MaxDrawdown   decimal.Decimal `json:"max_drawdown"`
	WinRate       decimal.Decimal `json:"win_rate"`
	ProfitLoss    decimal.Decimal `json:"profit_loss_ratio"` // 盈亏比
	TotalTrades   int             `json:"total_trades"`
	WinTrades     int             `json:"win_trades"`
	LossTrades    int             `json:"lose_trades"`
	AvgHoldDays   decimal.Decimal `json:"avg_hold_days"`
	Turnover      decimal.Decimal `json:"turnover"`
	FinalEquity   decimal.Decimal `json:"final_equity"`
	CreatedAt     time.Time       `json:"created_at"`
}

// EquityPoint 权益曲线点
type EquityPoint struct {
	Date     time.Time       `json:"date"`
	Equity   decimal.Decimal `json:"equity"`
	Cash     decimal.Decimal `json:"cash"`
	Position decimal.Decimal `json:"position_value"`
	Drawdown decimal.Decimal `json:"drawdown"`
}

// BacktestTrade 回测交易记录
type BacktestTrade struct {
	ID        string           `json:"id"`
	TaskID    string           `json:"task_id"`
	Symbol    string           `json:"symbol"`
	Side      models.OrderSide `json:"side"`
	Quantity  int64            `json:"quantity"`
	Price     decimal.Decimal  `json:"price"`
	Amount    decimal.Decimal  `json:"amount"`
	Commission decimal.Decimal `json:"commission"`
	Slippage  decimal.Decimal  `json:"slippage"`
	PnL       decimal.Decimal  `json:"pnl"`
	TradeAt   time.Time        `json:"trade_at"`
}
