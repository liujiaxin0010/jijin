package domain

import "context"

// BacktestTaskRepository 回测任务仓储
type BacktestTaskRepository interface {
	Create(ctx context.Context, task *BacktestTask) error
	GetByID(ctx context.Context, id string) (*BacktestTask, error)
	List(ctx context.Context, accountID string) ([]BacktestTask, error)
	UpdateStatus(ctx context.Context, id string, status string) error
}

// BacktestResultRepository 回测结果仓储
type BacktestResultRepository interface {
	Create(ctx context.Context, result *BacktestResult) error
	GetByTaskID(ctx context.Context, taskID string) (*BacktestResult, error)
}

// BacktestTradeRepository 回测交易仓储
type BacktestTradeRepository interface {
	BatchCreate(ctx context.Context, trades []BacktestTrade) error
	ListByTaskID(ctx context.Context, taskID string) ([]BacktestTrade, error)
}
