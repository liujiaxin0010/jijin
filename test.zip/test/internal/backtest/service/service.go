package service

import (
	"context"
	"fmt"
	"log/slog"

	"github.com/quant-platform/server/internal/backtest/domain"
)

// BacktestService 回测业务服务
type BacktestService struct {
	taskRepo   domain.BacktestTaskRepository
	resultRepo domain.BacktestResultRepository
	tradeRepo  domain.BacktestTradeRepository
	log        *slog.Logger
}

// NewBacktestService 创建回测服务
func NewBacktestService(
	taskRepo domain.BacktestTaskRepository,
	resultRepo domain.BacktestResultRepository,
	tradeRepo domain.BacktestTradeRepository,
	log *slog.Logger,
) *BacktestService {
	return &BacktestService{
		taskRepo:   taskRepo,
		resultRepo: resultRepo,
		tradeRepo:  tradeRepo,
		log:        log,
	}
}

// CreateTask 创建回测任务
func (s *BacktestService) CreateTask(ctx context.Context, task *domain.BacktestTask) error {
	task.Status = "pending"
	return s.taskRepo.Create(ctx, task)
}

// GetTask 获取回测任务
func (s *BacktestService) GetTask(ctx context.Context, id string) (*domain.BacktestTask, error) {
	return s.taskRepo.GetByID(ctx, id)
}

// ListTasks 列出回测任务
func (s *BacktestService) ListTasks(ctx context.Context, accountID string) ([]domain.BacktestTask, error) {
	return s.taskRepo.List(ctx, accountID)
}

// GetResult 获取回测结果
func (s *BacktestService) GetResult(ctx context.Context, taskID string) (*domain.BacktestResult, error) {
	return s.resultRepo.GetByTaskID(ctx, taskID)
}

// GetTrades 获取回测交易记录
func (s *BacktestService) GetTrades(ctx context.Context, taskID string) ([]domain.BacktestTrade, error) {
	return s.tradeRepo.ListByTaskID(ctx, taskID)
}

// RunBacktest 执行回测（异步）
func (s *BacktestService) RunBacktest(ctx context.Context, taskID string) error {
	task, err := s.taskRepo.GetByID(ctx, taskID)
	if err != nil {
		return fmt.Errorf("get task: %w", err)
	}

	if err := s.taskRepo.UpdateStatus(ctx, taskID, "running"); err != nil {
		return fmt.Errorf("update status: %w", err)
	}

	s.log.Info("backtest started", "task_id", taskID, "strategy_id", task.StrategyID)

	// TODO: 实际回测逻辑需要：
	// 1. 从行情服务获取历史K线数据
	// 2. 创建回测引擎实例
	// 3. 逐Bar驱动策略执行
	// 4. 收集交易记录和权益曲线
	// 5. 计算绩效指标
	// 6. 持久化结果

	_ = task
	return nil
}
