package http

import (
	"github.com/gin-gonic/gin"
	"github.com/quant-platform/server/internal/backtest/domain"
	"github.com/quant-platform/server/internal/backtest/service"
)

// Handler 回测HTTP处理器
type Handler struct {
	svc *service.BacktestService
}

// NewHandler 创建处理器
func NewHandler(svc *service.BacktestService) *Handler {
	return &Handler{svc: svc}
}

// RegisterRoutes 注册路由
func (h *Handler) RegisterRoutes(r *gin.RouterGroup) {
	g := r.Group("/backtests")

	g.POST("", h.createTask)
	g.GET("", h.listTasks)
	g.GET("/:id", h.getTask)
	g.POST("/:id/run", h.runBacktest)
	g.GET("/:id/result", h.getResult)
	g.GET("/:id/trades", h.getTrades)
}

func (h *Handler) createTask(c *gin.Context) {
	var task domain.BacktestTask
	if err := c.ShouldBindJSON(&task); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}
	if err := h.svc.CreateTask(c.Request.Context(), &task); err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(201, gin.H{"data": task})
}

func (h *Handler) getTask(c *gin.Context) {
	task, err := h.svc.GetTask(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(404, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": task})
}

func (h *Handler) listTasks(c *gin.Context) {
	tasks, err := h.svc.ListTasks(c.Request.Context(), c.Query("account_id"))
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": tasks})
}

func (h *Handler) runBacktest(c *gin.Context) {
	if err := h.svc.RunBacktest(c.Request.Context(), c.Param("id")); err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"message": "backtest started"})
}

func (h *Handler) getResult(c *gin.Context) {
	result, err := h.svc.GetResult(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(404, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": result})
}

func (h *Handler) getTrades(c *gin.Context) {
	trades, err := h.svc.GetTrades(c.Request.Context(), c.Param("id"))
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}
	c.JSON(200, gin.H{"data": trades})
}
