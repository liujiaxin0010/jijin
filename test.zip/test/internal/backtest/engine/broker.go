package engine

import (
	"time"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/internal/backtest/domain"
	"github.com/quant-platform/server/pkg/models"
)

// SimBroker 模拟撮合引擎
type SimBroker struct {
	Cash       decimal.Decimal
	commission decimal.Decimal
	slippage   decimal.Decimal
	positions  map[string]*simPosition
	trades     []domain.BacktestTrade
	prices     map[string]decimal.Decimal
}

type simPosition struct {
	Symbol   string
	Quantity int64
	AvgCost  decimal.Decimal
}

// NewSimBroker 创建模拟撮合引擎
func NewSimBroker(cash, commission, slippage decimal.Decimal) *SimBroker {
	return &SimBroker{
		Cash:       cash,
		commission: commission,
		slippage:   slippage,
		positions:  make(map[string]*simPosition),
		prices:     make(map[string]decimal.Decimal),
	}
}

// UpdatePrice 更新最新价格
func (b *SimBroker) UpdatePrice(symbol string, price decimal.Decimal) {
	b.prices[symbol] = price
}

// ExecuteOrder 执行订单（模拟撮合）
func (b *SimBroker) ExecuteOrder(symbol string, side models.OrderSide, quantity int64, price decimal.Decimal) {
	// 计算滑点后的成交价
	slip := price.Mul(b.slippage)
	execPrice := price
	if side == models.OrderBuy {
		execPrice = price.Add(slip)
	} else {
		execPrice = price.Sub(slip)
	}

	qty := decimal.NewFromInt(quantity)
	amount := execPrice.Mul(qty)
	comm := amount.Mul(b.commission)

	var pnl decimal.Decimal
	if side == models.OrderBuy {
		b.Cash = b.Cash.Sub(amount).Sub(comm)
		pos, ok := b.positions[symbol]
		if !ok {
			pos = &simPosition{Symbol: symbol}
			b.positions[symbol] = pos
		}
		// 更新平均成本
		totalCost := pos.AvgCost.Mul(decimal.NewFromInt(pos.Quantity)).Add(amount)
		pos.Quantity += quantity
		if pos.Quantity > 0 {
			pos.AvgCost = totalCost.Div(decimal.NewFromInt(pos.Quantity))
		}
	} else {
		b.Cash = b.Cash.Add(amount).Sub(comm)
		if pos, ok := b.positions[symbol]; ok {
			pnl = execPrice.Sub(pos.AvgCost).Mul(qty)
			pos.Quantity -= quantity
			if pos.Quantity <= 0 {
				delete(b.positions, symbol)
			}
		}
	}

	b.trades = append(b.trades, domain.BacktestTrade{
		TaskID:     "",
		Symbol:     symbol,
		Side:       side,
		Quantity:   quantity,
		Price:      execPrice,
		Amount:     amount,
		Commission: comm,
		Slippage:   slip.Mul(qty),
		PnL:        pnl,
		TradeAt:    time.Now(),
	})
}

// GetEquity 获取当前总权益
func (b *SimBroker) GetEquity() decimal.Decimal {
	equity := b.Cash
	for symbol, pos := range b.positions {
		if price, ok := b.prices[symbol]; ok {
			equity = equity.Add(price.Mul(decimal.NewFromInt(pos.Quantity)))
		}
	}
	return equity
}

// GetTrades 获取所有交易记录
func (b *SimBroker) GetTrades() []domain.BacktestTrade {
	return b.trades
}
