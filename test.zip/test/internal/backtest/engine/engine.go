package engine

import (
	"time"

	"github.com/shopspring/decimal"
	"github.com/quant-platform/server/internal/backtest/domain"
	"github.com/quant-platform/server/pkg/models"
)

// Engine 回测引擎
type Engine struct {
	task     *domain.BacktestTask
	broker   *SimBroker
	equity   []domain.EquityPoint
	trades   []domain.BacktestTrade
}

// NewEngine 创建回测引擎
func NewEngine(task *domain.BacktestTask) *Engine {
	return &Engine{
		task:   task,
		broker: NewSimBroker(task.InitCash, task.Commission, task.Slippage),
	}
}

// Run 运行回测（逐Bar模式）
func (e *Engine) Run(klines map[string][]BarData) *domain.BacktestResult {
	// 按日期遍历所有Bar
	dates := e.collectDates(klines)
	for _, date := range dates {
		for symbol, bars := range klines {
			for _, bar := range bars {
				if bar.Date.Equal(date) {
					e.broker.UpdatePrice(symbol, bar.Close)
				}
			}
		}
		// 记录权益曲线
		equity := e.broker.GetEquity()
		e.equity = append(e.equity, domain.EquityPoint{
			Date:     date,
			Equity:   equity,
			Cash:     e.broker.Cash,
			Position: equity.Sub(e.broker.Cash),
		})
	}

	e.trades = e.broker.GetTrades()
	return e.calculateResult()
}

// BarData K线数据
type BarData struct {
	Date   time.Time
	Open   decimal.Decimal
	High   decimal.Decimal
	Low    decimal.Decimal
	Close  decimal.Decimal
	Volume int64
}

// SubmitOrder 提交回测订单
func (e *Engine) SubmitOrder(symbol string, side models.OrderSide, quantity int64, price decimal.Decimal) {
	e.broker.ExecuteOrder(symbol, side, quantity, price)
}

// GetEquityCurve 获取权益曲线
func (e *Engine) GetEquityCurve() []domain.EquityPoint {
	return e.equity
}

// GetTrades 获取交易记录
func (e *Engine) GetTrades() []domain.BacktestTrade {
	return e.trades
}

func (e *Engine) collectDates(klines map[string][]BarData) []time.Time {
	dateSet := make(map[time.Time]bool)
	for _, bars := range klines {
		for _, bar := range bars {
			dateSet[bar.Date] = true
		}
	}
	dates := make([]time.Time, 0, len(dateSet))
	for d := range dateSet {
		dates = append(dates, d)
	}
	// 排序
	for i := 0; i < len(dates); i++ {
		for j := i + 1; j < len(dates); j++ {
			if dates[j].Before(dates[i]) {
				dates[i], dates[j] = dates[j], dates[i]
			}
		}
	}
	return dates
}

func (e *Engine) calculateResult() *domain.BacktestResult {
	result := &domain.BacktestResult{TaskID: e.task.ID}

	if len(e.equity) == 0 {
		return result
	}

	initEquity := e.task.InitCash
	finalEquity := e.equity[len(e.equity)-1].Equity
	result.FinalEquity = finalEquity
	result.TotalTrades = len(e.trades)

	// 总收益率
	if !initEquity.IsZero() {
		result.TotalReturn = finalEquity.Sub(initEquity).Div(initEquity)
	}

	// 最大回撤
	peak := initEquity
	maxDD := decimal.Zero
	for _, ep := range e.equity {
		if ep.Equity.GreaterThan(peak) {
			peak = ep.Equity
		}
		if !peak.IsZero() {
			dd := peak.Sub(ep.Equity).Div(peak)
			if dd.GreaterThan(maxDD) {
				maxDD = dd
			}
		}
	}
	result.MaxDrawdown = maxDD

	// 胜率和盈亏比
	var wins, losses int
	var totalProfit, totalLoss decimal.Decimal
	for _, t := range e.trades {
		if t.PnL.IsPositive() {
			wins++
			totalProfit = totalProfit.Add(t.PnL)
		} else if t.PnL.IsNegative() {
			losses++
			totalLoss = totalLoss.Add(t.PnL.Abs())
		}
	}
	result.WinTrades = wins
	result.LossTrades = losses
	if result.TotalTrades > 0 {
		result.WinRate = decimal.NewFromInt(int64(wins)).Div(decimal.NewFromInt(int64(result.TotalTrades)))
	}
	if losses > 0 && !totalLoss.IsZero() {
		avgWin := totalProfit.Div(decimal.NewFromInt(int64(max(wins, 1))))
		avgLoss := totalLoss.Div(decimal.NewFromInt(int64(losses)))
		result.ProfitLoss = avgWin.Div(avgLoss)
	}

	return result
}
