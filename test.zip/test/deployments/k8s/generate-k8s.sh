#!/bin/bash
# generate-k8s.sh - 根据模板生成所有微服务的K8s部署配置
# 用法: bash generate-k8s.sh

SERVICES=(
  "market-data:8081:2"
  "factor:8082:2"
  "strategy:8083:2"
  "backtest:8084:2"
  "portfolio:8085:1"
  "risk:8086:2"
  "order:8087:2"
  "account:8088:2"
  "analytics:8089:1"
  "notification:8090:1"
)

for entry in "${SERVICES[@]}"; do
  IFS=':' read -r name port replicas <<< "$entry"

  cat > "${name}-deployment.yaml" <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ${name}
  namespace: quant-platform
  labels:
    app: ${name}
spec:
  replicas: ${replicas}
  selector:
    matchLabels:
      app: ${name}
  template:
    metadata:
      labels:
        app: ${name}
    spec:
      containers:
        - name: ${name}
          image: quant-platform/${name}:latest
          ports:
            - containerPort: 8080
              name: http
            - containerPort: 9090
              name: grpc
          envFrom:
            - configMapRef:
                name: quant-platform-config
          resources:
            requests:
              cpu: 100m
              memory: 128Mi
            limits:
              cpu: 500m
              memory: 512Mi
          livenessProbe:
            httpGet:
              path: /health
              port: http
            initialDelaySeconds: 10
            periodSeconds: 15
          readinessProbe:
            httpGet:
              path: /health
              port: http
            initialDelaySeconds: 5
            periodSeconds: 10
---
apiVersion: v1
kind: Service
metadata:
  name: ${name}
  namespace: quant-platform
  labels:
    app: ${name}
spec:
  selector:
    app: ${name}
  ports:
    - name: http
      port: 8080
      targetPort: http
    - name: grpc
      port: 9090
      targetPort: grpc
  type: ClusterIP
EOF

  echo "Generated ${name}-deployment.yaml"
done
