package main

import (
	"context"
	"log/slog"
	"os"
	"os/signal"
	"syscall"

	"github.com/quant-platform/server/internal/strategy"
	"github.com/quant-platform/server/pkg/config"
	"github.com/quant-platform/server/pkg/logger"
)

func main() {
	cfg, err := config.Load("strategy")
	if err != nil {
		slog.Error("load config failed", "error", err)
		os.Exit(1)
	}

	log := logger.New(cfg.Log)
	ctx, cancel := signal.NotifyContext(context.Background(),
		os.Interrupt, syscall.SIGTERM)
	defer cancel()

	app, err := strategy.NewApp(ctx, cfg, log)
	if err != nil {
		log.Error("init app failed", "error", err)
		os.Exit(1)
	}

	log.Info("strategy service starting",
		"grpc_port", cfg.GRPC.Port,
		"http_port", cfg.HTTP.Port)

	if err := app.Run(ctx); err != nil {
		log.Error("app exited with error", "error", err)
		os.Exit(1)
	}
}
