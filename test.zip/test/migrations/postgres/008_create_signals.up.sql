-- 008_create_signals.up.sql
-- 策略信号表

CREATE TABLE IF NOT EXISTS signals (
    id          VARCHAR(36) PRIMARY KEY,
    strategy_id VARCHAR(36)    NOT NULL REFERENCES strategies(id),
    symbol      VARCHAR(20)    NOT NULL,
    side        VARCHAR(10)    NOT NULL,
    price       DECIMAL(20,4)  NOT NULL,
    quantity    DECIMAL(20,4)  NOT NULL,
    reason      TEXT,
    created_at  TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_signals_strategy_id ON signals(strategy_id);
CREATE INDEX idx_signals_created_at ON signals(created_at);
