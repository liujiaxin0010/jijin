-- 014_create_allocations.up.sql
-- 组合配置表

CREATE TABLE IF NOT EXISTS allocations (
    id              VARCHAR(36) PRIMARY KEY,
    portfolio_id    VARCHAR(36)    NOT NULL REFERENCES portfolios(id),
    strategy_id     VARCHAR(36)    REFERENCES strategies(id),
    symbol          VARCHAR(20),
    target_weight   DECIMAL(10,4)  NOT NULL DEFAULT 0,
    actual_weight   DECIMAL(10,4)  NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_allocations_portfolio_id ON allocations(portfolio_id);
