-- 006_create_strategies.up.sql
-- 策略表

CREATE TABLE IF NOT EXISTS strategies (
    id          VARCHAR(36) PRIMARY KEY,
    account_id  VARCHAR(36)  NOT NULL REFERENCES accounts(id),
    name        VARCHAR(128) NOT NULL,
    type        VARCHAR(20)  NOT NULL,
    description TEXT,
    params      JSONB,
    status      VARCHAR(20)  NOT NULL DEFAULT 'draft',
    version     INT          NOT NULL DEFAULT 1,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_strategies_account_id ON strategies(account_id);
CREATE INDEX idx_strategies_status ON strategies(status);
