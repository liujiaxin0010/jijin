-- 018_create_attributions.up.sql
-- 归因分析表

CREATE TABLE IF NOT EXISTS attributions (
    id          VARCHAR(36) PRIMARY KEY,
    report_id   VARCHAR(36)    NOT NULL REFERENCES performance_reports(id),
    type        VARCHAR(20)    NOT NULL,
    name        VARCHAR(128)   NOT NULL,
    return_val  DECIMAL(20,6),
    weight      DECIMAL(10,4),
    contribution DECIMAL(20,6),
    created_at  TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_attributions_report_id ON attributions(report_id);
