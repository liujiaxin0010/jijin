-- 009_create_orders.up.sql
-- 订单表

CREATE TABLE IF NOT EXISTS orders (
    id              VARCHAR(36) PRIMARY KEY,
    account_id      VARCHAR(36)    NOT NULL REFERENCES accounts(id),
    strategy_id     VARCHAR(36),
    symbol          VARCHAR(20)    NOT NULL,
    exchange        VARCHAR(20)    NOT NULL,
    side            VARCHAR(10)    NOT NULL,
    type            VARCHAR(20)    NOT NULL,
    status          VARCHAR(20)    NOT NULL DEFAULT 'pending',
    price           DECIMAL(20,4),
    quantity        DECIMAL(20,4)  NOT NULL,
    filled_qty      DECIMAL(20,4)  NOT NULL DEFAULT 0,
    avg_price       DECIMAL(20,4)  NOT NULL DEFAULT 0,
    algorithm       VARCHAR(20),
    algo_params     JSONB,
    created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_orders_account_id ON orders(account_id);
CREATE INDEX idx_orders_strategy_id ON orders(strategy_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created_at ON orders(created_at);
