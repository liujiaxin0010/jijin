-- 011_create_risk_rules.up.sql
-- 风控规则表

CREATE TABLE IF NOT EXISTS risk_rules (
    id          VARCHAR(36) PRIMARY KEY,
    account_id  VARCHAR(36)  NOT NULL REFERENCES accounts(id),
    name        VARCHAR(128) NOT NULL,
    type        VARCHAR(20)  NOT NULL,
    condition   JSONB        NOT NULL,
    action      VARCHAR(20)  NOT NULL DEFAULT 'warn',
    level       VARCHAR(10)  NOT NULL DEFAULT 'yellow',
    enabled     BOOLEAN      NOT NULL DEFAULT true,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_risk_rules_account_id ON risk_rules(account_id);
