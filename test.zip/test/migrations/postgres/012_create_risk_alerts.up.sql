-- 012_create_risk_alerts.up.sql
-- 风控告警表

CREATE TABLE IF NOT EXISTS risk_alerts (
    id          VARCHAR(36) PRIMARY KEY,
    account_id  VARCHAR(36)  NOT NULL REFERENCES accounts(id),
    rule_id     VARCHAR(36)  REFERENCES risk_rules(id),
    level       VARCHAR(10)  NOT NULL,
    type        VARCHAR(20)  NOT NULL,
    message     TEXT         NOT NULL,
    status      VARCHAR(20)  NOT NULL DEFAULT 'active',
    resolved_at TIMESTAMPTZ,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_risk_alerts_account_id ON risk_alerts(account_id);
CREATE INDEX idx_risk_alerts_level ON risk_alerts(level);
CREATE INDEX idx_risk_alerts_status ON risk_alerts(status);
