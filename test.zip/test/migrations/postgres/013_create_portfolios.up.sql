-- 013_create_portfolios.up.sql
-- 组合表

CREATE TABLE IF NOT EXISTS portfolios (
    id          VARCHAR(36) PRIMARY KEY,
    account_id  VARCHAR(36)  NOT NULL REFERENCES accounts(id),
    name        VARCHAR(128) NOT NULL,
    description TEXT,
    status      VARCHAR(20)  NOT NULL DEFAULT 'active',
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_portfolios_account_id ON portfolios(account_id);
