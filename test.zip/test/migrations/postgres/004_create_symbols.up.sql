-- 004_create_symbols.up.sql
-- 标的信息表

CREATE TABLE IF NOT EXISTS symbols (
    id          VARCHAR(36) PRIMARY KEY,
    code        VARCHAR(20)  NOT NULL,
    name        VARCHAR(128) NOT NULL,
    exchange    VARCHAR(20)  NOT NULL,
    asset_type  VARCHAR(20)  NOT NULL,
    status      VARCHAR(20)  NOT NULL DEFAULT 'active',
    list_date   DATE,
    delist_date DATE,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_symbols_code_exchange ON symbols(code, exchange);
