-- 019_create_notifications.up.sql
-- 通知表

CREATE TABLE IF NOT EXISTS notifications (
    id          VARCHAR(36) PRIMARY KEY,
    account_id  VARCHAR(36)  NOT NULL REFERENCES accounts(id),
    channel     VARCHAR(20)  NOT NULL,
    type        VARCHAR(20)  NOT NULL,
    title       VARCHAR(256) NOT NULL,
    content     TEXT         NOT NULL,
    status      VARCHAR(20)  NOT NULL DEFAULT 'pending',
    read_at     TIMESTAMPTZ,
    sent_at     TIMESTAMPTZ,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_account_id ON notifications(account_id);
CREATE INDEX idx_notifications_status ON notifications(status);
