-- 010_create_trades.up.sql
-- 成交表

CREATE TABLE IF NOT EXISTS trades (
    id          VARCHAR(36) PRIMARY KEY,
    order_id    VARCHAR(36)    NOT NULL REFERENCES orders(id),
    account_id  VARCHAR(36)    NOT NULL REFERENCES accounts(id),
    symbol      VARCHAR(20)    NOT NULL,
    exchange    VARCHAR(20)    NOT NULL,
    side        VARCHAR(10)    NOT NULL,
    price       DECIMAL(20,4)  NOT NULL,
    quantity    DECIMAL(20,4)  NOT NULL,
    commission  DECIMAL(20,4)  NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_trades_order_id ON trades(order_id);
CREATE INDEX idx_trades_account_id ON trades(account_id);
CREATE INDEX idx_trades_created_at ON trades(created_at);
