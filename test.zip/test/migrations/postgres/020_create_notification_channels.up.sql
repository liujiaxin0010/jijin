-- 020_create_notification_channels.up.sql
-- 通知渠道配置表

CREATE TABLE IF NOT EXISTS notification_channels (
    id          VARCHAR(36) PRIMARY KEY,
    account_id  VARCHAR(36)  NOT NULL REFERENCES accounts(id),
    channel     VARCHAR(20)  NOT NULL,
    enabled     BOOLEAN      NOT NULL DEFAULT true,
    config      JSONB,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notification_channels_account_id ON notification_channels(account_id);
