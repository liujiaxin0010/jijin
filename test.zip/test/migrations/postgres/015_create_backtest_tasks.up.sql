-- 015_create_backtest_tasks.up.sql
-- 回测任务表

CREATE TABLE IF NOT EXISTS backtest_tasks (
    id              VARCHAR(36) PRIMARY KEY,
    account_id      VARCHAR(36)    NOT NULL REFERENCES accounts(id),
    strategy_id     VARCHAR(36)    NOT NULL REFERENCES strategies(id),
    name            VARCHAR(128)   NOT NULL,
    symbol          VARCHAR(20)    NOT NULL,
    timeframe       VARCHAR(10)    NOT NULL,
    start_date      DATE           NOT NULL,
    end_date        DATE           NOT NULL,
    init_cash       DECIMAL(20,4)  NOT NULL DEFAULT 1000000,
    commission      DECIMAL(10,6)  NOT NULL DEFAULT 0.0003,
    slippage        DECIMAL(10,6)  NOT NULL DEFAULT 0.0001,
    status          VARCHAR(20)    NOT NULL DEFAULT 'pending',
    params          JSONB,
    created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_backtest_tasks_account_id ON backtest_tasks(account_id);
CREATE INDEX idx_backtest_tasks_status ON backtest_tasks(status);
