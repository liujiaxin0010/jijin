-- 017_create_performance_reports.up.sql
-- 绩效报告表

CREATE TABLE IF NOT EXISTS performance_reports (
    id              VARCHAR(36) PRIMARY KEY,
    account_id      VARCHAR(36)    NOT NULL REFERENCES accounts(id),
    portfolio_id    VARCHAR(36)    REFERENCES portfolios(id),
    period          VARCHAR(20)    NOT NULL,
    start_date      DATE           NOT NULL,
    end_date        DATE           NOT NULL,
    total_return    DECIMAL(20,6),
    annual_return   DECIMAL(20,6),
    sharpe_ratio    DECIMAL(10,4),
    max_drawdown    DECIMAL(10,6),
    volatility      DECIMAL(10,6),
    win_rate        DECIMAL(10,4),
    created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_performance_reports_account_id ON performance_reports(account_id);
