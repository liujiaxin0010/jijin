-- 016_create_backtest_results.up.sql
-- 回测结果表

CREATE TABLE IF NOT EXISTS backtest_results (
    id              VARCHAR(36) PRIMARY KEY,
    task_id         VARCHAR(36)    NOT NULL REFERENCES backtest_tasks(id),
    total_return    DECIMAL(20,6),
    annual_return   DECIMAL(20,6),
    sharpe_ratio    DECIMAL(10,4),
    max_drawdown    DECIMAL(10,6),
    win_rate        DECIMAL(10,4),
    profit_loss     DECIMAL(10,4),
    total_trades    INT            NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_backtest_results_task_id ON backtest_results(task_id);
