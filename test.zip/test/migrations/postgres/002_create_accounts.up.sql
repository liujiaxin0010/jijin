-- 002_create_accounts.up.sql
-- 账户表

CREATE TABLE IF NOT EXISTS accounts (
    id              VARCHAR(36) PRIMARY KEY,
    user_id         VARCHAR(36)    NOT NULL REFERENCES users(id),
    name            VARCHAR(128)   NOT NULL,
    type            VARCHAR(20)    NOT NULL DEFAULT 'live',
    status          VARCHAR(20)    NOT NULL DEFAULT 'active',
    balance         DECIMAL(20,4)  NOT NULL DEFAULT 0,
    available       DECIMAL(20,4)  NOT NULL DEFAULT 0,
    frozen          DECIMAL(20,4)  NOT NULL DEFAULT 0,
    currency        VARCHAR(10)    NOT NULL DEFAULT 'CNY',
    created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_accounts_user_id ON accounts(user_id);
