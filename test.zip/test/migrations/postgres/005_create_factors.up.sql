-- 005_create_factors.up.sql
-- 因子元数据表

CREATE TABLE IF NOT EXISTS factors (
    id          VARCHAR(36) PRIMARY KEY,
    name        VARCHAR(64)  NOT NULL UNIQUE,
    category    VARCHAR(20)  NOT NULL,
    expression  TEXT,
    description TEXT,
    params      JSONB,
    status      VARCHAR(20)  NOT NULL DEFAULT 'active',
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_factors_category ON factors(category);
