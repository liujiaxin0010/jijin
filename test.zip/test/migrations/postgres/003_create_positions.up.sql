-- 003_create_positions.up.sql
-- 持仓表

CREATE TABLE IF NOT EXISTS positions (
    id              VARCHAR(36) PRIMARY KEY,
    account_id      VARCHAR(36)    NOT NULL REFERENCES accounts(id),
    symbol          VARCHAR(20)    NOT NULL,
    exchange        VARCHAR(20)    NOT NULL,
    side            VARCHAR(10)    NOT NULL DEFAULT 'long',
    quantity        DECIMAL(20,4)  NOT NULL DEFAULT 0,
    available_qty   DECIMAL(20,4)  NOT NULL DEFAULT 0,
    frozen_qty      DECIMAL(20,4)  NOT NULL DEFAULT 0,
    avg_cost        DECIMAL(20,4)  NOT NULL DEFAULT 0,
    market_value    DECIMAL(20,4)  NOT NULL DEFAULT 0,
    unrealized_pnl  DECIMAL(20,4)  NOT NULL DEFAULT 0,
    realized_pnl    DECIMAL(20,4)  NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_positions_account_id ON positions(account_id);
CREATE UNIQUE INDEX idx_positions_account_symbol ON positions(account_id, symbol, exchange);
