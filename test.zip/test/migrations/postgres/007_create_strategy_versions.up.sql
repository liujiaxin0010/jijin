-- 007_create_strategy_versions.up.sql
-- 策略版本表

CREATE TABLE IF NOT EXISTS strategy_versions (
    id          VARCHAR(36) PRIMARY KEY,
    strategy_id VARCHAR(36)  NOT NULL REFERENCES strategies(id),
    version     INT          NOT NULL,
    params      JSONB,
    changelog   TEXT,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_strategy_versions_strategy_id ON strategy_versions(strategy_id);
CREATE UNIQUE INDEX idx_strategy_versions_unique ON strategy_versions(strategy_id, version);
