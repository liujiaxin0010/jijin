-- 003_create_equity_curves.up.sql
-- 回测权益曲线表

CREATE TABLE IF NOT EXISTS equity_curves (
    task_id     String,
    trade_date  Date,
    equity      Decimal(20,4),
    cash        Decimal(20,4),
    position_value Decimal(20,4)
) ENGINE = MergeTree()
PARTITION BY task_id
ORDER BY (task_id, trade_date);
