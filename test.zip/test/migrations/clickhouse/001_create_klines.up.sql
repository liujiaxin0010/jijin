-- 001_create_klines.up.sql
-- K线数据表 (时序数据)

CREATE TABLE IF NOT EXISTS klines (
    symbol      String,
    exchange    String,
    timeframe   String,
    open_time   DateTime,
    open        Decimal(20,4),
    high        Decimal(20,4),
    low         Decimal(20,4),
    close       Decimal(20,4),
    volume      Decimal(20,4),
    turnover    Decimal(20,4),
    trade_count UInt64 DEFAULT 0
) ENGINE = MergeTree()
PARTITION BY (symbol, toYYYYMM(open_time))
ORDER BY (symbol, exchange, timeframe, open_time)
TTL open_time + INTERVAL 10 YEAR;
