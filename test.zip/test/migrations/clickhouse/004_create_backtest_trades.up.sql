-- 004_create_backtest_trades.up.sql
-- 回测成交记录表

CREATE TABLE IF NOT EXISTS backtest_trades (
    task_id     String,
    symbol      String,
    side        String,
    price       Decimal(20,4),
    quantity    Decimal(20,4),
    commission  Decimal(20,4),
    pnl         Decimal(20,4),
    trade_time  DateTime
) ENGINE = MergeTree()
PARTITION BY task_id
ORDER BY (task_id, trade_time);
