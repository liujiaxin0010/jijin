-- 002_create_factor_values.up.sql
-- 因子值表 (时序数据)

CREATE TABLE IF NOT EXISTS factor_values (
    factor_id   String,
    symbol      String,
    trade_date  Date,
    value       Decimal(20,6),
    created_at  DateTime DEFAULT now()
) ENGINE = MergeTree()
PARTITION BY (factor_id, toYYYYMM(trade_date))
ORDER BY (factor_id, symbol, trade_date);
